# RaceDay API - PowerShell Startup Script
# Run this in PowerShell to start the API

Write-Host "=========================================="
Write-Host "   RaceDay API - PowerShell Startup" -ForegroundColor Green
Write-Host "=========================================="
Write-Host ""

# Step 1: Check .NET
Write-Host "[1/5] Checking .NET installation..." -ForegroundColor Cyan
$dotnetVersion = dotnet --version
Write-Host "? .NET $dotnetVersion is installed" -ForegroundColor Green
Write-Host ""

# Step 2: Navigate to project
Write-Host "[2/5] Navigating to project directory..." -ForegroundColor Cyan
$projectPath = "C:\Users\Student\source\repos\WebApplication2\WebApplication2"
if (Test-Path $projectPath) {
    Set-Location $projectPath
    Write-Host "? Project directory: $projectPath" -ForegroundColor Green
} else {
    Write-Host "ERROR: Project directory not found at $projectPath" -ForegroundColor Red
    Write-Host "Current location: $(Get-Location)" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# Step 3: Restore packages
Write-Host "[3/5] Restoring NuGet packages..." -ForegroundColor Cyan
dotnet restore
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Package restore failed" -ForegroundColor Red
    exit 1
}
Write-Host "? Packages restored successfully" -ForegroundColor Green
Write-Host ""

# Step 4: Create/Update database
Write-Host "[4/5] Setting up database..." -ForegroundColor Cyan
dotnet ef database update
if ($LASTEXITCODE -ne 0) {
    Write-Host "WARNING: Database setup had some issues, but continuing..." -ForegroundColor Yellow
}
Write-Host "? Database ready" -ForegroundColor Green
Write-Host ""

# Step 5: Start API
Write-Host "[5/5] Starting API server..." -ForegroundColor Cyan
Write-Host ""
Write-Host "=========================================="
Write-Host "   API Server Starting..." -ForegroundColor Green
Write-Host "=========================================="
Write-Host ""
Write-Host "The API will be available at:" -ForegroundColor Cyan
Write-Host "  HTTP:  http://localhost:5014" -ForegroundColor White
Write-Host "  HTTPS: https://localhost:7071" -ForegroundColor White
Write-Host ""
Write-Host "Swagger UI: http://localhost:5014/swagger/index.html" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Cyan
Write-Host ""
Write-Host "=========================================="
Write-Host ""

# Run the API
dotnet run
