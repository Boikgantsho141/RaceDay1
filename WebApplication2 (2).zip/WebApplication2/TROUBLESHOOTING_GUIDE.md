# ?? RaceDay API - Troubleshooting & Fix Guide

## ? Your Code is Correct!

Your build is **successful with no errors**. If it's not running, it's likely one of these common issues:

---

## ?? Most Common Issues & Fixes

### Issue 1: Database Not Created

**Symptoms:**
- Error: `Cannot open database "RaceDayDb"`
- Error: `Login failed for user`

**Fix:**
```bash
# Navigate to project directory
cd WebApplication2

# Create the database
dotnet ef database update

# Expected output:
# Done. No migrations to apply.
# (This means database was created successfully)
```

**If that doesn't work:**
```bash
# Clear and recreate migrations
dotnet ef migrations remove
dotnet ef migrations add InitialCreate
dotnet ef database update
```

---

### Issue 2: HTTPS Certificate Error

**Symptoms:**
- Error: `Unable to configure HTTPS endpoint`
- Error: `The certificate is not valid`

**Fix:**
```bash
# Trust the development certificate
dotnet dev-certs https --trust

# Clean and recreate certificate
dotnet dev-certs https --clean
dotnet dev-certs https

# Then run:
dotnet run
```

**On Mac/Linux:**
```bash
dotnet dev-certs https --trust --check-validity
```

---

### Issue 3: Port Already in Use

**Symptoms:**
- Error: `Address already in use`
- Error: `port 5014 is in use`

**Fix - Option A: Kill the process**
```bash
# Windows - Find and kill process on port 5014
netstat -ano | findstr :5014
taskkill /PID <PID> /F

# Mac/Linux
lsof -i :5014
kill -9 <PID>
```

**Fix - Option B: Use different port**
```bash
# Run on different port
dotnet run --urls "http://localhost:8080"
```

**Fix - Option C: Edit launchSettings.json**
```json
{
  "profiles": {
    "http": {
      "applicationUrl": "http://localhost:8888"  // Change port
    }
  }
}
```

---

### Issue 4: NuGet Packages Not Restored

**Symptoms:**
- Error: `The type or namespace name X could not be found`
- Error: `CS0246: The type or namespace name`

**Fix:**
```bash
# Clear NuGet cache
dotnet nuget locals all --clear

# Restore packages
dotnet restore

# Then build and run
dotnet build
dotnet run
```

---

### Issue 5: SQL Server LocalDB Not Installed

**Symptoms:**
- Error: `Cannot create database 'RaceDayDb'`
- Error: `Named Pipes Provider, error: 40`

**Fix - Install LocalDB:**

**Option A: Download Standalone LocalDB**
1. Go to: https://www.microsoft.com/en-us/sql-server/sql-server-express
2. Click "Download" for SQL Server Express
3. Choose "LocalDB" during installation
4. Restart your computer

**Option B: Use Visual Studio Installer**
1. Open Visual Studio Installer
2. Click "Modify"
3. Select "SQL Server Data Tools"
4. Install

**Option C: Use full SQL Server**
Edit `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=RaceDayDb;User Id=sa;Password=YourPassword;"
  }
}
```

---

### Issue 6: Connection String Wrong

**Symptoms:**
- Error: `Connection string 'DefaultConnection' not found`
- Error: `Invalid connection string`

**Fix:**
Verify `appsettings.json` has:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=RaceDayDb;Trusted_Connection=true;"
  }
}
```

**Note:** Must have exactly this connection string name "DefaultConnection"

---

### Issue 7: Visual Studio Build Issues

**Symptoms:**
- Build succeeds but nothing happens
- Run button doesn't work

**Fix:**
```bash
# Clean solution
dotnet clean

# Rebuild solution
dotnet build

# Run from command line instead
dotnet run

# Or in Visual Studio:
# 1. Build ? Clean Solution
# 2. Build ? Rebuild Solution
# 3. Debug ? Start Debugging (F5)
```

---

### Issue 8: Wrong Working Directory

**Symptoms:**
- Error: `appsettings.json not found`
- Error: `Connection string not found`

**Fix:**
```bash
# Make sure you're in the project directory
cd C:\Users\Student\source\repos\WebApplication2\WebApplication2

# Verify you can see Program.cs
dir Program.cs

# Then run
dotnet run
```

---

## ?? Step-by-Step: Get Your API Running

### Step 1: Verify Prerequisites

```bash
# Check .NET is installed
dotnet --version
# Should show: 8.0.x or higher

# Check SQL Server LocalDB exists
sqllocaldb info
# Should show: (localdb)\mssqllocaldb
```

If LocalDB is not installed, see **Issue 5** above.

### Step 2: Navigate to Project

```bash
cd C:\Users\Student\source\repos\WebApplication2\WebApplication2
```

### Step 3: Restore Packages

```bash
dotnet restore
```

**Expected output:**
```
Restoring packages for WebApplication2.csproj...
Restore completed in X.XX seconds.
```

### Step 4: Create Database

```bash
dotnet ef database update
```

**Expected output:**
```
Build succeeded.
Done. No migrations to apply.
```

### Step 5: Run the API

```bash
dotnet run
```

**Expected output:**
```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: https://localhost:7071
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5014
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to exit.
```

### Step 6: Open in Browser

Open: `http://localhost:5014/swagger/index.html`

You should see the Swagger UI with all API endpoints!

---

## ?? Specific Error Messages & Solutions

### Error: "Connection string 'DefaultConnection' not found"

**Solution:**
```bash
# Check appsettings.json exists
dir appsettings.json

# Make sure it has DefaultConnection:
type appsettings.json | findstr DefaultConnection
# Should show the connection string line

# If not, recreate it with:
# (Copy the JSON from the earlier section)
```

---

### Error: "Cannot open database 'RaceDayDb'"

**Solution:**
```bash
# Create the database
dotnet ef database update

# If that fails, try:
dotnet ef migrations add InitialCreate
dotnet ef database update
```

---

### Error: "The type or namespace name 'RaceDayDbContext' could not be found"

**Solution:**
```bash
# Restore NuGet packages
dotnet restore

# Rebuild
dotnet clean
dotnet build

# Run
dotnet run
```

---

### Error: "HTTPS certificate is not trusted"

**Solution:**
```bash
# Trust the certificate
dotnet dev-certs https --trust

# Confirm it's trusted
dotnet dev-certs https --check-validity

# Run
dotnet run
```

---

### Error: "Address already in use"

**Solution:**
```bash
# Find what's using port 5014
netstat -ano | findstr :5014

# Kill it (replace <PID> with number from above)
taskkill /PID <PID> /F

# Or use a different port
dotnet run --urls "http://localhost:9999"
```

---

## ?? If Nothing Works: Complete Reset

Follow these steps in order:

```bash
# 1. Stop the application (Ctrl+C if running)

# 2. Navigate to project
cd C:\Users\Student\source\repos\WebApplication2\WebApplication2

# 3. Clean everything
dotnet clean
del bin -r
del obj -r

# 4. Clear NuGet cache
dotnet nuget locals all --clear

# 5. Restore packages
dotnet restore

# 6. Rebuild
dotnet build

# 7. Trust certificate
dotnet dev-certs https --clean
dotnet dev-certs https
dotnet dev-certs https --trust

# 8. Create database
dotnet ef database update

# 9. Run
dotnet run
```

Expected output:
```
Now listening on: https://localhost:7071
Now listening on: http://localhost:5014
Application started. Press Ctrl+C to exit.
```

---

## ? Verification Checklist

After fixing, verify everything works:

- [ ] Build succeeds: `dotnet build` ?
- [ ] Database created: `dotnet ef database update` ?
- [ ] API runs: `dotnet run` ?
- [ ] Swagger loads: Open `http://localhost:5014/swagger` ?
- [ ] Can register user: Try POST /api/auth/register ?
- [ ] Can login: Try POST /api/auth/login ?
- [ ] Can create event: Try POST /api/events ?

---

## ?? Common Scenarios

### Scenario: "It was working yesterday, now it's not"

**Likely cause:** Database or certificate issue

**Fix:**
```bash
# Try these in order:
dotnet clean
dotnet restore
dotnet ef database update
dotnet run
```

---

### Scenario: "I get different errors each time"

**Likely cause:** Project files not in sync

**Fix:**
```bash
# Complete reset
dotnet clean
del bin -r
del obj -r
dotnet restore
dotnet build
dotnet run
```

---

### Scenario: "It runs but I can't access it"

**Likely cause:** Wrong URL or port

**Check:**
1. Run output shows which port: `Now listening on: http://localhost:XXXX`
2. Open that exact URL in browser
3. Add `/swagger` to see Swagger UI

---

## ?? Get Help

### Check Logs

When running, look for these outputs:

```
? GOOD:
  Now listening on: https://localhost:7071
  Now listening on: http://localhost:5014
  Application started

? BAD:
  Build failed
  Error: 
  Unhandled exception:
```

### Check Project Files

Verify these files exist:
- ? `Program.cs` - Main startup file
- ? `appsettings.json` - Configuration
- ? `WebApplication2.csproj` - Project file
- ? `Controllers/` - Has controller files
- ? `Models/` - Has model files
- ? `Data/RaceDayDbContext.cs` - Database context

---

## ?? Pro Tips

### Tip 1: Use Visual Studio Debug
```
Debug ? Start Debugging (F5)
or
Debug ? Start Without Debugging (Ctrl+F5)
```

### Tip 2: Check Output Window
```
In Visual Studio:
View ? Output Window
Shows detailed build and runtime logs
```

### Tip 3: Use Package Manager Console
```
In Visual Studio:
View ? Package Manager Console
Run: Update-Database
```

### Tip 4: Set Startup Project
```
In Visual Studio:
Right-click WebApplication2 project
Set as Startup Project
```

---

## ?? What Should Happen

### When you run `dotnet run`:

```
1. Build completes successfully
   ? Build succeeded
   
2. HTTP Server starts
   ? Now listening on: http://localhost:5014
   ? Now listening on: https://localhost:7071
   
3. Application ready
   ? Application started. Press Ctrl+C to exit.
   
4. You can access API
   ? Open browser to http://localhost:5014/swagger
   
5. All endpoints work
   ? Test endpoints in Swagger UI
```

---

## ?? Success!

When you see this output:

```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: https://localhost:7071
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5014
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to exit.
```

Your API is running! Open: `http://localhost:5014/swagger/index.html`

---

## ?? Still Having Issues?

Tell me:
1. **What error do you see?** (Exact error message)
2. **When does it fail?** (During build, run, or accessing?)
3. **What did you try?** (Which fix steps)
4. **Any warnings in output?** (Full console output)

Then I can provide a more specific fix!

---

**Your code is correct. Let's get it running!** ??
