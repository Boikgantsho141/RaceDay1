# ?? RaceDay API - NEW Complete Startup Guide

## ? Your API is Ready - Here's How to Run It

I've created **3 new ways** to start your API. Choose one:

---

## ?? Option 1: Windows Command Prompt (EASIEST)

### Step 1: Click the Batch File
**Double-click this file:**
```
start-api-complete.bat
```

**Location:** In your project root folder (C:\Users\Student\source\repos\WebApplication2\)

### Step 2: Wait for Setup
The script will:
- ? Check .NET installation
- ? Navigate to project
- ? Restore packages
- ? Build project
- ? Create database
- ? Start API server

### Step 3: See Success Message
You should see:
```
==========================================
    Starting RaceDay API Server
==========================================

APIs will be available at:
  HTTP:  http://localhost:5014
  HTTPS: https://localhost:7071

Swagger UI: http://localhost:5014/swagger/index.html

Press Ctrl+C to stop the server
```

### Step 4: Open Browser
Open this URL in your browser:
```
http://localhost:5014/swagger/index.html
```

**Done!** ?? Your API is running!

---

## ?? Option 2: Windows PowerShell

### Step 1: Open PowerShell as Administrator
1. Press `Windows Key + X`
2. Select "Windows PowerShell (Admin)"
3. Click "Yes" when asked

### Step 2: Run the Script
Copy and paste this command:
```powershell
& "C:\Users\Student\source\repos\WebApplication2\start-api.ps1"
```

Or navigate first:
```powershell
cd "C:\Users\Student\source\repos\WebApplication2"
.\start-api.ps1
```

### Step 3: Allow Script Execution
If you get a permission error, run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Then run the script again.

### Step 4: Open Browser
```
http://localhost:5014/swagger/index.html
```

---

## ?? Option 3: Manual Commands (If Scripts Don't Work)

### Step 1: Open Command Prompt
Press `Windows Key + R`, type `cmd`, press Enter

### Step 2: Run Commands One by One

**Command 1:**
```cmd
cd C:\Users\Student\source\repos\WebApplication2\WebApplication2
```

Wait for prompt to return.

**Command 2:**
```cmd
dotnet restore
```

Wait for "Restore completed" message.

**Command 3:**
```cmd
dotnet build
```

Wait for "Build succeeded" message.

**Command 4:**
```cmd
dotnet ef database update
```

Wait for "Done" message.

**Command 5:**
```cmd
dotnet run
```

Wait for:
```
Now listening on: http://localhost:5014
Now listening on: https://localhost:7071
Application started. Press Ctrl+C to exit.
```

### Step 3: Open Browser
```
http://localhost:5014/swagger/index.html
```

---

## ? What to Expect

### Startup Process (5-10 minutes first time)

1. **Package Restore** - Downloads NuGet packages
2. **Build** - Compiles your code
3. **Database Setup** - Creates RaceDayDb
4. **Server Start** - Starts listening on ports
5. **Ready** - API is live!

### Success Signs

? See "Now listening on: http://localhost:5014"
? See "Application started. Press Ctrl+C to exit."
? No red ERROR messages
? Browser loads Swagger UI

### Swagger UI Features

Once Swagger loads, you can:
- ? See all 31 endpoints
- ? Click "Try it out" on any endpoint
- ? Test endpoints directly
- ? View request/response format

---

## ?? First Test

### Test 1: List Events

1. Find: `GET /api/events`
2. Click: "Try it out"
3. Click: "Execute"
4. **Expected Result:** Status 200, empty array `[]`

If you see that, your API is working! ?

### Test 2: Register User

1. Find: `POST /api/auth/register`
2. Click: "Try it out"
3. Enter test data:
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "password": "Password123!",
  "role": 1
}
```
4. Click: "Execute"
5. **Expected Result:** Status 200 with user profile returned

---

## ?? Troubleshooting

### Issue: "File not found" or "Cannot find path"
**Solution:**
Make sure you're in the correct directory:
```
C:\Users\Student\source\repos\WebApplication2\WebApplication2
```

(The folder that contains `Program.cs`)

---

### Issue: "Permission denied" (PowerShell)
**Solution:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Then run the script again.

---

### Issue: "Port 5014 already in use"
**Solution:**
```cmd
netstat -ano | findstr :5014
taskkill /PID <PID> /F
dotnet run
```

Replace `<PID>` with the number shown.

---

### Issue: "Cannot open database 'RaceDayDb'"
**Solution:**
Make sure SQL Server LocalDB is installed:
```cmd
sqllocaldb info
```

If not installed, download from:
https://www.microsoft.com/en-us/sql-server/sql-server-express

---

### Issue: "Build failed"
**Solution:**
```cmd
dotnet clean
dotnet restore
dotnet build
```

---

## ?? Status Checklist

Before running, verify:

- [ ] .NET 8 installed (`dotnet --version`)
- [ ] SQL Server LocalDB installed (`sqllocaldb info`)
- [ ] Project files present (`Program.cs`, `appsettings.json`)
- [ ] You're in correct directory (has `Program.cs`)

---

## ?? Recommended Method

### Best Overall: Use the Batch File

1. **Double-click:** `start-api-complete.bat`
2. **Wait 2-3 minutes** for setup
3. **See success message**
4. **Open browser** to `http://localhost:5014/swagger`

**Why?** It handles everything automatically, error checking included.

---

## ?? Files I Created for You

| File | Purpose |
|------|---------|
| `start-api-complete.bat` | Complete batch script (Windows) |
| `start-api.ps1` | PowerShell script (Windows) |
| `start-api.sh` | Bash script (Mac/Linux) |

---

## ?? Let's Start

### Choose Your Method:

**Easiest:** Double-click `start-api-complete.bat`

**Alternative:** Run `start-api.ps1` in PowerShell

**Manual:** Follow the 5-command sequence above

---

## ? Your API Features

Once running, you'll have access to:

? **31 REST API Endpoints**
? **User Authentication** (Register/Login)
? **Event Management** (CRUD)
? **Event Categories** (CRUD)
? **Event Enrolments** (CRUD)
? **Results Management** (CRUD)
? **Swagger/OpenAPI Docs**
? **Role-Based Access Control**
? **Session Management**
? **SQL Server Database**

---

## ?? Summary

Your API is **completely ready to run**. I've given you 3 ways to start it:

1. **Easiest:** Double-click batch file
2. **Advanced:** Run PowerShell script
3. **Manual:** Run commands yourself

**Just choose one and your API will be running in 5-10 minutes!**

---

**Ready to start?** Pick a method above and begin! ??
