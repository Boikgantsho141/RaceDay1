using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Controllers;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;
using Xunit;

namespace WebApplication2.Tests.Controllers
{
    public class ResultsControllerTests
    {
        private RaceDayDbContext CreateDbContext()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        private ResultsController CreateResultsController(RaceDayDbContext context, int? userId = null, string? userRole = null)
        {
            var logger = new MockLogger<ResultsController>();
            var controller = new ResultsController(context, logger);

            var httpContext = new DefaultHttpContext();
            var session = new MockSession();

            if (userId.HasValue)
                session.SetInt32("UserId", userId.Value);
            if (userRole != null)
                session.SetString("UserRole", userRole);

            httpContext.Session = session;
            controller.ControllerContext.HttpContext = httpContext;

            return controller;
        }

        [Fact]
        public async Task CreateResult_AsOrganiser_ShouldRecordResult()
        {
            // Arrange
            using var context = CreateDbContext();

            var participant = new User
            {
                FirstName = "Runner",
                LastName = "Participant",
                Email = "runner@example.com",
                PhoneNumber = "1234567890",
                PasswordHash = "hash",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var eventEntity = new Event
            {
                Name = "Marathon",
                Description = "Marathon Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "City",
                Distance = 42.2,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var category = new Category
            {
                Name = "Adults",
                Description = "Adult Category",
                CreatedAt = DateTime.UtcNow
            };

            context.Users.Add(participant);
            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            category.EventId = eventEntity.Id;
            context.Categories.Add(category);
            await context.SaveChangesAsync();

            var enrolment = new EventEnrolment
            {
                ParticipantId = participant.Id,
                EventId = eventEntity.Id,
                CategoryId = category.Id,
                EnrolledAt = DateTime.UtcNow
            };

            context.EventEnrolments.Add(enrolment);
            await context.SaveChangesAsync();

            var controller = CreateResultsController(context, userId: 1, userRole: UserRole.Organiser.ToString());

            var createResultDto = new CreateResultDto
            {
                ParticipantId = participant.Id,
                FinishTime = new TimeSpan(3, 45, 30),
                FinishingPosition = 1
            };

            // Act
            var result = await controller.CreateResult(eventEntity.Id, createResultDto);

            // Assert
            var createdResult = Assert.IsType<Microsoft.AspNetCore.Mvc.CreatedAtActionResult>(result.Result);
            var resultDto = Assert.IsType<ResultResponseDto>(createdResult.Value);
            Assert.Equal(participant.Id, resultDto.ParticipantId);
            Assert.Equal(1, resultDto.FinishingPosition);
        }

        [Fact]
        public async Task CreateResult_AsParticipant_ShouldReturnForbidden()
        {
            // Arrange
            using var context = CreateDbContext();

            var eventEntity = new Event
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            var controller = CreateResultsController(context, userId: 2, userRole: UserRole.Participant.ToString());

            var createResultDto = new CreateResultDto
            {
                ParticipantId = 2,
                FinishTime = new TimeSpan(1, 0, 0),
                FinishingPosition = 1
            };

            // Act
            var result = await controller.CreateResult(eventEntity.Id, createResultDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ForbidResult>(result.Result);
        }

        [Fact]
        public async Task GetResultsByEvent_AsOrganiser_ShouldReturnResults()
        {
            // Arrange
            using var context = CreateDbContext();

            var participant = new User
            {
                FirstName = "Runner",
                LastName = "Test",
                Email = "runner@test.com",
                PhoneNumber = "1234567890",
                PasswordHash = "hash",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var eventEntity = new Event
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(participant);
            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            var result = new Result
            {
                ParticipantId = participant.Id,
                EventId = eventEntity.Id,
                FinishTime = new TimeSpan(2, 30, 0),
                FinishingPosition = 1,
                RecordedAt = DateTime.UtcNow
            };

            context.Results.Add(result);
            await context.SaveChangesAsync();

            var controller = CreateResultsController(context, userId: 1, userRole: UserRole.Organiser.ToString());

            // Act
            var resultAction = await controller.GetResultsByEvent(eventEntity.Id);

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(resultAction.Result);
            var results = Assert.IsType<List<ResultResponseDto>>(okResult.Value);
            Assert.Single(results);
        }

        [Fact]
        public async Task GetResultById_ByParticipant_ShouldReturnOwnResult()
        {
            // Arrange
            using var context = CreateDbContext();

            var participant = new User
            {
                FirstName = "Participant",
                LastName = "User",
                Email = "part@example.com",
                PhoneNumber = "9876543210",
                PasswordHash = "hash",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var eventEntity = new Event
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(participant);
            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            var result = new Result
            {
                ParticipantId = participant.Id,
                EventId = eventEntity.Id,
                FinishTime = new TimeSpan(2, 0, 0),
                FinishingPosition = 5,
                RecordedAt = DateTime.UtcNow
            };

            context.Results.Add(result);
            await context.SaveChangesAsync();

            var controller = CreateResultsController(context, userId: participant.Id, userRole: UserRole.Participant.ToString());

            // Act
            var resultAction = await controller.GetResultById(eventEntity.Id, result.Id);

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(resultAction.Result);
            var returnedResult = Assert.IsType<ResultResponseDto>(okResult.Value);
            Assert.Equal(result.Id, returnedResult.Id);
        }
    }
}
