using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Controllers;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;
using Xunit;

namespace WebApplication2.Tests.Controllers
{
    public class EnrolmentsControllerTests
    {
        private RaceDayDbContext CreateDbContext()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        private EnrolmentsController CreateEnrolmentsController(RaceDayDbContext context, int? userId = null, string? userRole = null)
        {
            var logger = new MockLogger<EnrolmentsController>();
            var controller = new EnrolmentsController(context, logger);

            var httpContext = new DefaultHttpContext();
            var session = new MockSession();

            if (userId.HasValue)
                session.SetInt32("UserId", userId.Value);
            if (userRole != null)
                session.SetString("UserRole", userRole);

            httpContext.Session = session;
            controller.ControllerContext.HttpContext = httpContext;

            return controller;
        }

        [Fact]
        public async Task EnrolInEvent_AsParticipant_ShouldCreateEnrolment()
        {
            // Arrange
            using var context = CreateDbContext();

            var eventEntity = new Event
            {
                Name = "Marathon",
                Description = "City Marathon",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "City Park",
                Distance = 42.2,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var category = new Category
            {
                Name = "Adults",
                Description = "Adult participants",
                CreatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            category.EventId = eventEntity.Id;
            context.Categories.Add(category);
            await context.SaveChangesAsync();

            var controller = CreateEnrolmentsController(context, userId: 2, userRole: UserRole.Participant.ToString());

            var enrollDto = new EnrollEventDto
            {
                CategoryId = category.Id
            };

            // Act
            var result = await controller.EnrolInEvent(eventEntity.Id, enrollDto);

            // Assert
            var createdResult = Assert.IsType<Microsoft.AspNetCore.Mvc.CreatedAtActionResult>(result.Result);
            var enrolment = Assert.IsType<EventEnrolmentResponseDto>(createdResult.Value);
            Assert.Equal(2, enrolment.ParticipantId);
            Assert.Equal(eventEntity.Id, enrolment.EventId);
        }

        [Fact]
        public async Task EnrolInEvent_AsOrganiser_ShouldReturnForbidden()
        {
            // Arrange
            using var context = CreateDbContext();

            var eventEntity = new Event
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var category = new Category
            {
                Name = "Category",
                Description = "Category",
                CreatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            category.EventId = eventEntity.Id;
            context.Categories.Add(category);
            await context.SaveChangesAsync();

            var controller = CreateEnrolmentsController(context, userId: 1, userRole: UserRole.Organiser.ToString());

            var enrollDto = new EnrollEventDto
            {
                CategoryId = category.Id
            };

            // Act
            var result = await controller.EnrolInEvent(eventEntity.Id, enrollDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ForbidResult>(result.Result);
        }

        [Fact]
        public async Task EnrolInEvent_WhenAlreadyEnrolled_ShouldReturnBadRequest()
        {
            // Arrange
            using var context = CreateDbContext();

            var eventEntity = new Event
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var category = new Category
            {
                Name = "Category",
                Description = "Category",
                CreatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            category.EventId = eventEntity.Id;
            context.Categories.Add(category);
            await context.SaveChangesAsync();

            var existingEnrolment = new EventEnrolment
            {
                ParticipantId = 2,
                EventId = eventEntity.Id,
                CategoryId = category.Id,
                EnrolledAt = DateTime.UtcNow
            };

            context.EventEnrolments.Add(existingEnrolment);
            await context.SaveChangesAsync();

            var controller = CreateEnrolmentsController(context, userId: 2, userRole: UserRole.Participant.ToString());

            var enrollDto = new EnrollEventDto
            {
                CategoryId = category.Id
            };

            // Act
            var result = await controller.EnrolInEvent(eventEntity.Id, enrollDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public async Task GetEnrolmentsByEvent_AsOrganiser_ShouldReturnEnrolments()
        {
            // Arrange
            using var context = CreateDbContext();

            var eventEntity = new Event
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var category = new Category
            {
                Name = "Category",
                Description = "Category",
                CreatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            category.EventId = eventEntity.Id;
            context.Categories.Add(category);
            await context.SaveChangesAsync();

            var enrolment = new EventEnrolment
            {
                ParticipantId = 2,
                EventId = eventEntity.Id,
                CategoryId = category.Id,
                EnrolledAt = DateTime.UtcNow
            };

            context.EventEnrolments.Add(enrolment);
            await context.SaveChangesAsync();

            var controller = CreateEnrolmentsController(context, userId: 1, userRole: UserRole.Organiser.ToString());

            // Act
            var result = await controller.GetEnrolmentsByEvent(eventEntity.Id);

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result.Result);
            var enrolments = Assert.IsType<List<EventEnrolmentResponseDto>>(okResult.Value);
            Assert.Single(enrolments);
        }

        [Fact]
        public async Task GetEnrolmentsByEvent_AsParticipant_ShouldReturnForbidden()
        {
            // Arrange
            using var context = CreateDbContext();

            var eventEntity = new Event
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            var controller = CreateEnrolmentsController(context, userId: 2, userRole: UserRole.Participant.ToString());

            // Act
            var result = await controller.GetEnrolmentsByEvent(eventEntity.Id);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ForbidResult>(result.Result);
        }
    }
}
