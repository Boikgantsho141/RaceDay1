using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Controllers;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;
using WebApplication2.Services;
using Xunit;

namespace WebApplication2.Tests.Controllers
{
    public class AuthControllerTests
    {
        private RaceDayDbContext CreateDbContext()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        private AuthController CreateAuthController(RaceDayDbContext context)
        {
            var authService = new AuthenticationService();
            var logger = new MockLogger<AuthController>();
            var controller = new AuthController(context, authService, logger);

            // Mock session
            var httpContext = new DefaultHttpContext();
            httpContext.Session = new MockSession();
            controller.ControllerContext.HttpContext = httpContext;

            return controller;
        }

        [Fact]
        public async Task Register_WithValidData_ShouldCreateUser()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateAuthController(context);
            var registerDto = new RegisterDto
            {
                FirstName = "John",
                LastName = "Doe",
                Email = "john@example.com",
                PhoneNumber = "1234567890",
                Password = "Password123!",
                Role = UserRole.Participant
            };

            // Act
            var result = await controller.Register(registerDto);

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result.Result);
            var returnedUser = Assert.IsType<UserProfileDto>(okResult.Value);
            Assert.Equal("john@example.com", returnedUser.Email);
            Assert.Equal(UserRole.Participant, returnedUser.Role);
        }

        [Fact]
        public async Task Register_WithDuplicateEmail_ShouldReturnBadRequest()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateAuthController(context);

            var existingUser = new User
            {
                FirstName = "Existing",
                LastName = "User",
                Email = "existing@example.com",
                PhoneNumber = "1111111111",
                PasswordHash = "hashedpass",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(existingUser);
            await context.SaveChangesAsync();

            var registerDto = new RegisterDto
            {
                FirstName = "Duplicate",
                LastName = "User",
                Email = "existing@example.com",
                PhoneNumber = "2222222222",
                Password = "Password123!",
                Role = UserRole.Organiser
            };

            // Act
            var result = await controller.Register(registerDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.BadRequestObjectResult>(result.Result);
        }

        [Fact]
        public void Login_WithValidCredentials_ShouldReturnUser()
        {
            // Arrange
            using var context = CreateDbContext();
            var authService = new AuthenticationService();
            var controller = CreateAuthController(context);

            var password = "Password123!";
            var user = new User
            {
                FirstName = "Login",
                LastName = "Test",
                Email = "login@example.com",
                PhoneNumber = "3333333333",
                PasswordHash = authService.HashPassword(password),
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(user);
            context.SaveChanges();

            var loginDto = new LoginDto
            {
                Email = "login@example.com",
                Password = password
            };

            // Act
            var result = controller.Login(loginDto);

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result.Result);
            var returnedUser = Assert.IsType<UserProfileDto>(okResult.Value);
            Assert.Equal("login@example.com", returnedUser.Email);
        }

        [Fact]
        public void Login_WithInvalidPassword_ShouldReturnUnauthorized()
        {
            // Arrange
            using var context = CreateDbContext();
            var authService = new AuthenticationService();
            var controller = CreateAuthController(context);

            var user = new User
            {
                FirstName = "Test",
                LastName = "User",
                Email = "test@example.com",
                PhoneNumber = "4444444444",
                PasswordHash = authService.HashPassword("CorrectPassword123!"),
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(user);
            context.SaveChanges();

            var loginDto = new LoginDto
            {
                Email = "test@example.com",
                Password = "WrongPassword123!"
            };

            // Act
            var result = controller.Login(loginDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.UnauthorizedObjectResult>(result.Result);
        }

        [Fact]
        public void Logout_ShouldClearSession()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateAuthController(context);
            var session = controller.ControllerContext.HttpContext.Session as MockSession;

            session!.SetInt32("UserId", 1);
            session.SetString("UserEmail", "test@example.com");

            // Act
            var result = controller.Logout();

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result);
            Assert.Null(session.GetInt32("UserId"));
        }
    }

    // Mock implementations for testing
    public class MockSession : ISession
    {
        private readonly Dictionary<string, object> _sessionData = new();

        public string Id => Guid.NewGuid().ToString();
        public IEnumerable<string> Keys => _sessionData.Keys;
        public bool IsAvailable => true;

        public void Set(string key, byte[] value)
        {
            _sessionData[key] = value;
        }

        public bool TryGetValue(string key, out byte[]? value)
        {
            if (_sessionData.TryGetValue(key, out var obj))
            {
                value = obj as byte[];
                return true;
            }
            value = null;
            return false;
        }

        public void Remove(string key) => _sessionData.Remove(key);
        public void Clear() => _sessionData.Clear();
        public Task CommitAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
        public Task LoadAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
    }

    public class MockLogger<T> : Microsoft.Extensions.Logging.ILogger<T>
    {
        public IDisposable BeginScope<TState>(TState state) => null!;
        public bool IsEnabled(Microsoft.Extensions.Logging.LogLevel logLevel) => true;
        public void Log<TState>(Microsoft.Extensions.Logging.LogLevel logLevel, Microsoft.Extensions.Logging.EventId eventId,
            TState state, Exception? exception, Func<TState, Exception?, string> formatter) { }
    }

    public static class SessionExtensions
    {
        public static void SetInt32(this ISession session, string key, int value)
        {
            session.Set(key, BitConverter.GetBytes(value));
        }

        public static int? GetInt32(this ISession session, string key)
        {
            if (session.TryGetValue(key, out var data) && data.Length >= 4)
            {
                return BitConverter.ToInt32(data, 0);
            }
            return null;
        }

        public static void SetString(this ISession session, string key, string value)
        {
            session.Set(key, System.Text.Encoding.UTF8.GetBytes(value));
        }

        public static string? GetString(this ISession session, string key)
        {
            if (session.TryGetValue(key, out var data))
            {
                return System.Text.Encoding.UTF8.GetString(data);
            }
            return null;
        }
    }
}
