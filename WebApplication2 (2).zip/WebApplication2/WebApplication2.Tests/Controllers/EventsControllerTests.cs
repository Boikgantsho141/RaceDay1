using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Controllers;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;
using WebApplication2.Services;
using Xunit;

namespace WebApplication2.Tests.Controllers
{
    public class EventsControllerTests
    {
        private RaceDayDbContext CreateDbContext()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        private EventsController CreateEventsController(RaceDayDbContext context, int? userId = null, string? userRole = null)
        {
            var logger = new MockLogger<EventsController>();
            var controller = new EventsController(context, logger);

            var httpContext = new DefaultHttpContext();
            var session = new MockSession();

            if (userId.HasValue)
                session.SetInt32("UserId", userId.Value);
            if (userRole != null)
                session.SetString("UserRole", userRole);

            httpContext.Session = session;
            controller.ControllerContext.HttpContext = httpContext;

            return controller;
        }

        [Fact]
        public async Task GetAllEvents_ShouldReturnAllEvents()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context);

            var event1 = new Event
            {
                Name = "Marathon",
                Description = "City Marathon",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "City Park",
                Distance = 42.2,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Events.Add(event1);
            await context.SaveChangesAsync();

            // Act
            var result = await controller.GetAllEvents();

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result.Result);
            var events = Assert.IsType<List<EventResponseDto>>(okResult.Value);
            Assert.Single(events);
        }

        [Fact]
        public async Task CreateEvent_AsOrganiser_ShouldCreateEvent()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context, userId: 1, userRole: UserRole.Organiser.ToString());

            var createDto = new CreateEventDto
            {
                Name = "Cycling Event",
                Description = "City cycling",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Downtown",
                Distance = 50.0,
                EventType = EventType.Cycle
            };

            // Act
            var result = await controller.CreateEvent(createDto);

            // Assert
            var createdResult = Assert.IsType<Microsoft.AspNetCore.Mvc.CreatedAtActionResult>(result.Result);
            var returnedEvent = Assert.IsType<EventResponseDto>(createdResult.Value);
            Assert.Equal("Cycling Event", returnedEvent.Name);
            Assert.Equal(1, returnedEvent.OrganiserId);
        }

        [Fact]
        public async Task CreateEvent_AsParticipant_ShouldReturnForbidden()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context, userId: 2, userRole: UserRole.Participant.ToString());

            var createDto = new CreateEventDto
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run
            };

            // Act
            var result = await controller.CreateEvent(createDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ForbidResult>(result.Result);
        }

        [Fact]
        public async Task CreateEvent_WhenNotAuthenticated_ShouldReturnUnauthorized()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context);

            var createDto = new CreateEventDto
            {
                Name = "Event",
                Description = "Event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run
            };

            // Act
            var result = await controller.CreateEvent(createDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.UnauthorizedObjectResult>(result.Result);
        }

        [Fact]
        public async Task UpdateEvent_ByOwner_ShouldUpdateEvent()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context, userId: 1, userRole: UserRole.Organiser.ToString());

            var eventEntity = new Event
            {
                Name = "Original Name",
                Description = "Original Description",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Original Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            var updateDto = new UpdateEventDto
            {
                Name = "Updated Name",
                Description = "Updated Description",
                EventDate = DateTime.Now.AddMonths(2),
                Location = "Updated Location",
                Distance = 20.0,
                EventType = EventType.Cycle
            };

            // Act
            var result = await controller.UpdateEvent(eventEntity.Id, updateDto);

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result);
            var updatedEvent = Assert.IsType<EventResponseDto>(okResult.Value);
            Assert.Equal("Updated Name", updatedEvent.Name);
        }

        [Fact]
        public async Task UpdateEvent_ByNonOwner_ShouldReturnForbidden()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context, userId: 2, userRole: UserRole.Organiser.ToString());

            var eventEntity = new Event
            {
                Name = "Event by Organiser 1",
                Description = "Description",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            var updateDto = new UpdateEventDto
            {
                Name = "Updated",
                Description = "Updated",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Updated",
                Distance = 15.0,
                EventType = EventType.Run
            };

            // Act
            var result = await controller.UpdateEvent(eventEntity.Id, updateDto);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ForbidResult>(result);
        }

        [Fact]
        public async Task DeleteEvent_ByOwner_ShouldDeleteEvent()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context, userId: 1, userRole: UserRole.Organiser.ToString());

            var eventEntity = new Event
            {
                Name = "Event to Delete",
                Description = "Description",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            // Act
            var result = await controller.DeleteEvent(eventEntity.Id);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result);
            var deletedEvent = await context.Events.FirstOrDefaultAsync(e => e.Id == eventEntity.Id);
            Assert.Null(deletedEvent);
        }

        [Fact]
        public async Task GetEventById_ShouldReturnEvent()
        {
            // Arrange
            using var context = CreateDbContext();
            var controller = CreateEventsController(context);

            var eventEntity = new Event
            {
                Name = "Specific Event",
                Description = "Description",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Location",
                Distance = 10.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            // Act
            var result = await controller.GetEventById(eventEntity.Id);

            // Assert
            var okResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result.Result);
            var returnedEvent = Assert.IsType<EventResponseDto>(okResult.Value);
            Assert.Equal("Specific Event", returnedEvent.Name);
        }
    }
}
