using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;
using Xunit;

namespace WebApplication2.Tests.Data
{
    public class RaceDayDbContextTests
    {
        private RaceDayDbContext CreateDbContext()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        [Fact]
        public async Task User_CanBeAdded()
        {
            // Arrange
            using var context = CreateDbContext();
            var user = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Email = "john@example.com",
                PhoneNumber = "1234567890",
                PasswordHash = "hashedpassword",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            // Act
            context.Users.Add(user);
            await context.SaveChangesAsync();

            // Assert
            var retrievedUser = await context.Users.FirstOrDefaultAsync(u => u.Email == "john@example.com");
            Assert.NotNull(retrievedUser);
            Assert.Equal("John", retrievedUser.FirstName);
        }

        [Fact]
        public async Task Event_CanBeCreatedAndRetrieved()
        {
            // Arrange
            using var context = CreateDbContext();
            var eventEntity = new Event
            {
                Name = "City Marathon",
                Description = "Annual city marathon",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "City Park",
                Distance = 42.2,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            // Act
            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            // Assert
            var retrievedEvent = await context.Events.FirstOrDefaultAsync(e => e.Name == "City Marathon");
            Assert.NotNull(retrievedEvent);
            Assert.Equal("City Marathon", retrievedEvent.Name);
            Assert.Equal(42.2, retrievedEvent.Distance);
        }

        [Fact]
        public async Task Category_CanBeAssociatedWithEvent()
        {
            // Arrange
            using var context = CreateDbContext();
            var eventEntity = new Event
            {
                Name = "Half Marathon",
                Description = "Half marathon event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Downtown",
                Distance = 21.1,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var category = new Category
            {
                Name = "Under 20",
                Description = "Participants under 20 years old",
                CreatedAt = DateTime.UtcNow
            };

            // Act
            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            category.EventId = eventEntity.Id;
            context.Categories.Add(category);
            await context.SaveChangesAsync();

            // Assert
            var retrievedCategory = await context.Categories.FirstOrDefaultAsync(c => c.Name == "Under 20");
            Assert.NotNull(retrievedCategory);
            Assert.Equal(eventEntity.Id, retrievedCategory.EventId);
        }

        [Fact]
        public async Task EventEnrolment_CanBeCreated()
        {
            // Arrange
            using var context = CreateDbContext();
            var user = new User
            {
                FirstName = "Jane",
                LastName = "Doe",
                Email = "jane@example.com",
                PhoneNumber = "0987654321",
                PasswordHash = "hashedpassword",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var eventEntity = new Event
            {
                Name = "Trail Run",
                Description = "Mountain trail run",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "Mountains",
                Distance = 15.0,
                EventType = EventType.Run,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var category = new Category
            {
                Name = "Senior",
                Description = "Senior participants",
                CreatedAt = DateTime.UtcNow
            };

            // Act
            context.Users.Add(user);
            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            category.EventId = eventEntity.Id;
            context.Categories.Add(category);
            await context.SaveChangesAsync();

            var enrolment = new EventEnrolment
            {
                ParticipantId = user.Id,
                EventId = eventEntity.Id,
                CategoryId = category.Id,
                EnrolledAt = DateTime.UtcNow
            };

            context.EventEnrolments.Add(enrolment);
            await context.SaveChangesAsync();

            // Assert
            var retrievedEnrolment = await context.EventEnrolments.FirstOrDefaultAsync(e => e.ParticipantId == user.Id);
            Assert.NotNull(retrievedEnrolment);
            Assert.Equal(eventEntity.Id, retrievedEnrolment.EventId);
        }

        [Fact]
        public async Task Result_CanBeRecorded()
        {
            // Arrange
            using var context = CreateDbContext();
            var user = new User
            {
                FirstName = "Bob",
                LastName = "Smith",
                Email = "bob@example.com",
                PhoneNumber = "5555555555",
                PasswordHash = "hashedpassword",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var eventEntity = new Event
            {
                Name = "City Cycle",
                Description = "City cycling event",
                EventDate = DateTime.Now.AddMonths(1),
                Location = "City Streets",
                Distance = 50.0,
                EventType = EventType.Cycle,
                OrganiserId = 1,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            // Act
            context.Users.Add(user);
            context.Events.Add(eventEntity);
            await context.SaveChangesAsync();

            var result = new Result
            {
                ParticipantId = user.Id,
                EventId = eventEntity.Id,
                FinishTime = new TimeSpan(2, 30, 0),
                FinishingPosition = 1,
                RecordedAt = DateTime.UtcNow
            };

            context.Results.Add(result);
            await context.SaveChangesAsync();

            // Assert
            var retrievedResult = await context.Results.FirstOrDefaultAsync(r => r.ParticipantId == user.Id);
            Assert.NotNull(retrievedResult);
            Assert.Equal(1, retrievedResult.FinishingPosition);
        }

        [Fact]
        public async Task EmailUniquenessConstraint_EnforcesDuplicates()
        {
            // Arrange
            using var context = CreateDbContext();
            var user1 = new User
            {
                FirstName = "User1",
                LastName = "Test",
                Email = "duplicate@example.com",
                PhoneNumber = "1111111111",
                PasswordHash = "hashedpassword",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            var user2 = new User
            {
                FirstName = "User2",
                LastName = "Test",
                Email = "duplicate@example.com",
                PhoneNumber = "2222222222",
                PasswordHash = "hashedpassword",
                Role = UserRole.Participant,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            context.Users.Add(user1);
            await context.SaveChangesAsync();

            // Act & Assert
            context.Users.Add(user2);
            var ex = await Assert.ThrowsAsync<DbUpdateException>(async () => await context.SaveChangesAsync());
            Assert.NotNull(ex);
        }
    }
}
