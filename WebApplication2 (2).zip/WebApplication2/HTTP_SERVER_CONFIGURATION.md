# RaceDay API - HTTP Server Configuration Guide

## Overview

The RaceDay API is fully configured to connect to and work with HTTP servers. It's built on ASP.NET Core 8.0 which provides built-in HTTP server capabilities.

---

## Current HTTP Configuration

### Launch Profiles (launchSettings.json)

The API is configured with multiple launch profiles:

```json
{
  "profiles": {
    "http": {
      "commandName": "Project",
      "applicationUrl": "http://localhost:5014",
      "launchUrl": "swagger"
    },
    "https": {
      "commandName": "Project",
      "applicationUrl": "https://localhost:7071;http://localhost:5014",
      "launchUrl": "swagger"
    },
    "IIS Express": {
      "commandName": "IISExpress",
      "applicationUrl": "http://localhost:10277",
      "sslPort": 44361
    }
  }
}
```

### Available Ports

| Protocol | Port | Profile | Use Case |
|----------|------|---------|----------|
| HTTP | 5014 | http, https | Local development |
| HTTPS | 7071 | https | Secure development |
| HTTP | 10277 | IIS Express | IIS Express development |
| HTTPS | 44361 | IIS Express | IIS Express secure |

---

## Running the API with HTTP Server

### Method 1: Default HTTP Server (Kestrel)

ASP.NET Core uses **Kestrel** as the default HTTP server. Run the API simply with:

```bash
dotnet run
```

This will:
- ? Start the Kestrel HTTP server
- ? Listen on `http://localhost:5014`
- ? Listen on `https://localhost:7071`
- ? Launch Swagger UI in browser
- ? Accept HTTP and HTTPS connections

**Expected Output:**
```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: https://localhost:7071
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5014
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to exit.
```

### Method 2: HTTP-Only Server

To run only on HTTP (not HTTPS):

```bash
dotnet run --launch-profile http
```

This will:
- ? Listen only on `http://localhost:5014`
- ? Disable HTTPS requirement
- ? Useful for testing without certificate issues

### Method 3: HTTPS-Only Server

To run only on HTTPS:

```bash
dotnet run --launch-profile https
```

This will:
- ? Listen on `https://localhost:7071` and `http://localhost:5014`
- ? Require HTTPS for secure connections
- ? Redirect HTTP to HTTPS

### Method 4: IIS Express

If you have Visual Studio installed with IIS Express:

```bash
dotnet run --launch-profile "IIS Express"
```

Or launch from Visual Studio's debug button.

---

## HTTP Server Configuration in Program.cs

The API is configured in `Program.cs` with proper HTTP/HTTPS setup:

```csharp
var app = builder.Build();

// HTTP/HTTPS configuration
app.UseHttpsRedirection();      // Redirect HTTP to HTTPS
app.UseCors("AllowAll");        // Enable cross-origin requests
app.UseSession();               // Enable session support
app.UseAuthorization();         // Enable authorization

app.MapControllers();           // Map all API endpoints

app.Run();                       // Start HTTP server
```

---

## Connecting Client Applications to the API

### JavaScript/React Client

```javascript
// Connect to API
const API_URL = 'http://localhost:5014';

// Register user
fetch(`${API_URL}/api/auth/register`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  credentials: 'include',  // Important: include cookies for sessions
  body: JSON.stringify({
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@example.com',
    phoneNumber: '1234567890',
    password: 'Password123!',
    role: 1
  })
})
.then(response => response.json())
.then(data => console.log('User registered:', data));
```

### Python Client

```python
import requests

API_URL = 'http://localhost:5014'
session = requests.Session()

# Register user
response = session.post(
    f'{API_URL}/api/auth/register',
    json={
        'firstName': 'John',
        'lastName': 'Doe',
        'email': 'john@example.com',
        'phoneNumber': '1234567890',
        'password': 'Password123!',
        'role': 1
    }
)

print(response.json())
```

### Postman/Insomnia

1. **Base URL:** `http://localhost:5014`
2. **Add endpoint:** `/api/auth/register`
3. **Method:** POST
4. **Headers:**
   - `Content-Type: application/json`
5. **Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "password": "Password123!",
  "role": 1
}
```

### C# Client

```csharp
using HttpClient client = new HttpClient();
client.BaseAddress = new Uri("http://localhost:5014");

// Register user
var content = new StringContent(
    JsonConvert.SerializeObject(new {
        firstName = "John",
        lastName = "Doe",
        email = "john@example.com",
        phoneNumber = "1234567890",
        password = "Password123!",
        role = 1
    }),
    Encoding.UTF8,
    "application/json"
);

HttpResponseMessage response = await client.PostAsync("/api/auth/register", content);
string result = await response.Content.ReadAsStringAsync();
Console.WriteLine(result);
```

---

## HTTP Protocol Support

### Supported HTTP Methods

| Method | Used For | Examples |
|--------|----------|----------|
| GET | Retrieve data | Get users, Get events, Get results |
| POST | Create data | Register, Login, Create event, Enrol |
| PUT | Update data | Update profile, Update event, Update result |
| DELETE | Remove data | Delete event, Cancel enrolment |

### HTTP Status Codes

| Code | Meaning | When Used |
|------|---------|-----------|
| 200 | OK | Successful retrieval |
| 201 | Created | Resource successfully created |
| 400 | Bad Request | Invalid input data |
| 401 | Unauthorized | Not authenticated |
| 403 | Forbidden | Not authorized for action |
| 404 | Not Found | Resource doesn't exist |
| 500 | Server Error | Server error occurred |

### Example HTTP Requests

**Register User:**
```http
POST /api/auth/register HTTP/1.1
Host: localhost:5014
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "password": "Password123!",
  "role": 1
}
```

**Login User:**
```http
POST /api/auth/login HTTP/1.1
Host: localhost:5014
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "Password123!"
}
```

**Get Events:**
```http
GET /api/events HTTP/1.1
Host: localhost:5014
```

**Create Event (Authenticated):**
```http
POST /api/events HTTP/1.1
Host: localhost:5014
Content-Type: application/json
Cookie: session_id=xxxxx

{
  "name": "City Marathon",
  "description": "Annual city marathon",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "Central Park",
  "distance": 42.2,
  "eventType": 0
}
```

---

## CORS Configuration

The API is configured to accept requests from any origin:

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()      // Accept from any origin
               .AllowAnyMethod()      // Accept any HTTP method
               .AllowAnyHeader();     // Accept any header
    });
});
```

### For Production

Update CORS to be more restrictive:

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecific", builder =>
    {
        builder.WithOrigins("https://yourdomain.com")
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});
```

---

## Session Configuration

Sessions use HTTP cookies to maintain user state:

```csharp
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);  // 30-min timeout
    options.Cookie.HttpOnly = true;                  // Secure
    options.Cookie.IsEssential = true;               // Required
});
```

### Session Flow

1. **Register/Login** ? Session created
2. **HTTP Request** ? Session cookie sent automatically
3. **API** ? Validates session, processes request
4. **HTTP Response** ? Returns data with session cookie
5. **Logout** ? Session cleared

---

## Proxying Through Another Server

### Using nginx

```nginx
upstream raceday_api {
    server localhost:5014;
}

server {
    listen 80;
    server_name api.example.com;

    location / {
        proxy_pass http://raceday_api;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection keep-alive;
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### Using Apache

```apache
<VirtualHost *:80>
    ServerName api.example.com
    
    ProxyPreserveHost On
    ProxyPass / http://localhost:5014/
    ProxyPassReverse / http://localhost:5014/
</VirtualHost>
```

### Using IIS

1. Install Application Request Routing (ARR)
2. Create reverse proxy rule:
   - **Pattern:** `.*`
   - **Rewrite URL:** `http://localhost:5014/{R:0}`

---

## Testing HTTP Connectivity

### Using curl

```bash
# Test GET request
curl http://localhost:5014/api/events

# Test POST request
curl -X POST http://localhost:5014/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName":"John",
    "lastName":"Doe",
    "email":"john@example.com",
    "phoneNumber":"1234567890",
    "password":"Password123!",
    "role":1
  }'

# Test with session
curl -X POST http://localhost:5014/api/auth/login \
  -H "Content-Type: application/json" \
  -c cookies.txt \
  -d '{
    "email":"john@example.com",
    "password":"Password123!"
  }'

# Use session cookie in subsequent request
curl http://localhost:5014/api/users/profile \
  -b cookies.txt
```

### Using PowerShell

```powershell
# Test GET request
Invoke-RestMethod -Uri "http://localhost:5014/api/events" -Method Get

# Test POST request
$body = @{
    firstName = "John"
    lastName = "Doe"
    email = "john@example.com"
    phoneNumber = "1234567890"
    password = "Password123!"
    role = 1
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:5014/api/auth/register" `
    -Method Post `
    -Headers @{"Content-Type"="application/json"} `
    -Body $body
```

---

## Swagger/OpenAPI HTTP Documentation

The API provides interactive HTTP documentation at:

```
http://localhost:5014/swagger/index.html
```

This shows:
- ? All HTTP endpoints
- ? Request/response schemas
- ? HTTP status codes
- ? Try-it-out functionality
- ? Real HTTP requests/responses

---

## Troubleshooting HTTP Connectivity

### Issue: Connection refused

**Solution:**
```bash
# Verify API is running
dotnet run

# Check if port is in use
netstat -ano | findstr :5014

# Kill process if needed
taskkill /PID <PID> /F
```

### Issue: HTTPS certificate error

**Solution:**
```bash
# Trust development certificate
dotnet dev-certs https --trust

# Or run on HTTP only
dotnet run --launch-profile http
```

### Issue: CORS errors

**Solution:**
Check browser console for CORS errors. API is configured to allow all origins, but your client must:
- Include `credentials: 'include'` in fetch
- Use correct Content-Type header
- Handle cookies properly

### Issue: Session not persisting

**Solution:**
Ensure:
- Cookies are enabled in client
- `credentials: 'include'` in fetch (JavaScript)
- `Session.Set()` is called after login
- Session timeout hasn't expired

---

## Performance Tuning

### Kestrel Configuration

Add to `Program.cs`:

```csharp
builder.WebHost.ConfigureKestrel(serverOptions =>
{
    serverOptions.ListenLocalhost(5014);              // HTTP port
    serverOptions.ListenLocalhost(7071, 
        options => options.UseHttps());               // HTTPS port
});
```

### Connection Limits

```csharp
builder.WebHost.ConfigureKestrel(serverOptions =>
{
    serverOptions.Limits.MaxConcurrentConnections = 100;
    serverOptions.Limits.MaxConcurrentUpgradedConnections = 100;
    serverOptions.Limits.MaxRequestBodySize = 30_000_000; // 30MB
});
```

---

## Production Deployment

### Azure App Service

```bash
# Publish for production
dotnet publish -c Release -o ./publish

# Deploy to Azure
az webapp up --name raceday-api --resource-group my-rg --runtime "dotnet:8"
```

### Docker

```dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:8.0
WORKDIR /app
COPY ./publish .
EXPOSE 80
ENTRYPOINT ["dotnet", "WebApplication2.dll"]
```

```bash
docker build -t raceday-api .
docker run -p 80:80 raceday-api
```

### AWS EC2

```bash
# SSH into instance
ssh -i key.pem ec2-user@instance-ip

# Deploy API
dotnet run --urls "http://0.0.0.0:5014"
```

---

## Summary

Your RaceDay API is **fully connected to HTTP servers** with:

? **Kestrel HTTP Server** - Built-in ASP.NET Core
? **Multiple Ports** - HTTP (5014) and HTTPS (7071)
? **CORS Support** - Accept requests from any origin
? **Session Management** - HTTP cookies for state
? **Swagger/OpenAPI** - Live HTTP documentation
? **Production Ready** - Can be deployed to any web server

**Get started:** `dotnet run` and navigate to `http://localhost:5014/swagger/index.html`

---

For more information, see the main README.md and API_DOCUMENTATION.md
