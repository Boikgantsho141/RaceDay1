# RaceDay API - Setup and Run Instructions

## System Requirements

- Windows 10/11 or macOS with .NET 8.0 support
- Visual Studio 2022 Community Edition (or higher)
- SQL Server 2019+ or SQL Server Express/LocalDB
- .NET 8.0 SDK
- Git (for version control)

## Step-by-Step Setup

### 1. Prerequisites Installation

#### Install .NET 8.0 SDK
- Download from: https://dotnet.microsoft.com/download/dotnet/8.0
- Verify installation: `dotnet --version`

#### Install SQL Server LocalDB
- LocalDB is included with Visual Studio 2022
- Or download from: https://www.microsoft.com/en-us/sql-server/sql-server-express

#### Verify Command Line Tools
```bash
dotnet --version          # Should show 8.0.x
git --version            # Should show Git version
```

### 2. Clone and Open the Project

```bash
# Clone the repository
git clone <your-repository-url>
cd WebApplication2

# Open in Visual Studio
start WebApplication2.sln
```

Or use Visual Studio's built-in Git tools to clone the repository.

### 3. Restore NuGet Packages

The packages are automatically restored when you open the solution in Visual Studio.

Alternatively, from command line:
```bash
dotnet restore
```

### 4. Database Setup

#### Option A: Using Entity Framework CLI

```bash
# Navigate to the project directory
cd WebApplication2

# Create the database
dotnet ef database update

# To see the SQL being generated
dotnet ef migrations script
```

#### Option B: Verify Connection String

Edit `WebApplication2/appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=RaceDayDb;Trusted_Connection=true;"
  }
}
```

**Connection String Breakdown:**
- `Server=(localdb)\\mssqllocaldb` - Uses LocalDB (included with Visual Studio)
- `Database=RaceDayDb` - Database name
- `Trusted_Connection=true` - Uses Windows authentication

For full SQL Server:
```
Server=localhost;Database=RaceDayDb;User Id=sa;Password=YourPassword;
```

### 5. Run the Application

#### From Visual Studio
1. Select `WebApplication2` as the startup project
2. Press `F5` or click "Start Debugging"
3. The application will launch at `https://localhost:5001`

#### From Command Line
```bash
cd WebApplication2
dotnet run
```

### 6. Access the API

**Swagger UI**: https://localhost:5001/swagger/index.html

This provides an interactive interface to test all API endpoints.

## Running Tests

### From Visual Studio
1. Open Test Explorer: View ? Test Explorer
2. Click "Run All Tests" or run specific tests
3. View results in Test Explorer window

### From Command Line
```bash
# Run all tests
dotnet test

# Run with verbose output
dotnet test --verbosity detailed

# Run specific test project
dotnet test WebApplication2.Tests

# Run with coverage report
dotnet test /p:CollectCoverage=true
```

## Quick Start API Testing

### 1. Register as Organiser
Open Swagger UI and navigate to Auth endpoints:
```json
POST /api/auth/register
{
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "organiser@example.com",
  "phoneNumber": "1234567890",
  "password": "Password123!",
  "role": 0
}
```

### 2. Register as Participant
```json
POST /api/auth/register
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "participant@example.com",
  "phoneNumber": "0987654321",
  "password": "Password123!",
  "role": 1
}
```

### 3. Login
```json
POST /api/auth/login
{
  "email": "organiser@example.com",
  "password": "Password123!"
}
```

### 4. Create Event (as Organiser)
```json
POST /api/events
{
  "name": "City Marathon 2024",
  "description": "Annual city marathon",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "Central Park",
  "distance": 42.2,
  "eventType": 0
}
```

### 5. Create Category
```json
POST /api/events/1/categories
{
  "name": "Adults",
  "description": "For participants 18+"
}
```

### 6. Enrol in Event (as Participant)
First, login as participant, then:
```json
POST /api/events/1/enrolments
{
  "categoryId": 1
}
```

### 7. Record Result (as Organiser)
Login as organiser, then:
```json
POST /api/events/1/results
{
  "participantId": 2,
  "finishTime": "02:30:45.1234567",
  "finishingPosition": 1
}
```

## Configuration Files

### appsettings.json
Contains database connection string and logging configuration.

### launchSettings.json
Located in `Properties/`, controls:
- Application URL (https://localhost:5001)
- Environment (Development/Production)
- Launch browser on startup

To change the port:
```json
{
  "profiles": {
    "https": {
      "commandName": "Project",
      "launchBrowser": true,
      "applicationUrl": "https://localhost:7000;http://localhost:5000",
      ...
    }
  }
}
```

## Development Workflow

### Creating a Feature Branch
```bash
git checkout -b feature/my-feature
```

### Making Commits
```bash
# After making changes
git add .
git commit -m "Add descriptive commit message"
git push origin feature/my-feature
```

### Running Locally Before Pushing
```bash
# Build
dotnet build

# Run tests
dotnet test

# Run application
dotnet run
```

## Troubleshooting

### Issue: "Cannot connect to database"
**Solution:**
```bash
# Verify SQL Server is running
# Check connection string in appsettings.json
# Try creating database manually:
dotnet ef database update
```

### Issue: "Port 5001 already in use"
**Solution:**
```bash
# Find process using port
netstat -ano | findstr :5001

# Kill the process (Windows)
taskkill /PID <PID> /F

# Or change port in launchSettings.json
```

### Issue: "HTTPS certificate error"
**Solution:**
```bash
dotnet dev-certs https --clean
dotnet dev-certs https --trust
```

### Issue: "NuGet package restore failed"
**Solution:**
```bash
# Clear NuGet cache
dotnet nuget locals all --clear

# Restore packages
dotnet restore
```

### Issue: "Tests fail on first run"
**Solution:**
- Ensure database is created: `dotnet ef database update`
- Run tests multiple times (sometimes timing issues)
- Check that SQL Server/LocalDB is running

## Useful Commands

```bash
# Build solution
dotnet build

# Build in Release mode
dotnet build --configuration Release

# Run application
dotnet run

# Run tests
dotnet test

# Create migration (if you modify models)
dotnet ef migrations add MigrationName

# Apply migrations
dotnet ef database update

# Remove last migration
dotnet ef migrations remove

# Update database packages
dotnet add package Microsoft.EntityFrameworkCore --version 8.0.0

# View Entity Framework help
dotnet ef --help
```

## Development Best Practices

1. **Always create a feature branch** before making changes
2. **Run tests locally** before pushing changes
3. **Use descriptive commit messages** (at least 20 commits required)
4. **Follow existing code style** and conventions
5. **Write unit tests** for new features
6. **Update documentation** when adding new endpoints

## Deployment Checklist

- [ ] All tests pass
- [ ] Code builds without warnings
- [ ] Database migrations run successfully
- [ ] Swagger documentation is complete
- [ ] All endpoints have proper error handling
- [ ] Password hashing is implemented
- [ ] Role-based access control is enforced
- [ ] Git history shows meaningful commits
- [ ] README is updated
- [ ] CI/CD workflow passes

## Support Resources

- .NET Documentation: https://docs.microsoft.com/dotnet/
- Entity Framework Core: https://docs.microsoft.com/en-us/ef/core/
- ASP.NET Core: https://docs.microsoft.com/en-us/aspnet/core/
- SQL Server: https://docs.microsoft.com/en-us/sql/sql-server/

## Next Steps

1. Familiarize yourself with the project structure
2. Review the API documentation in `API_DOCUMENTATION.md`
3. Test endpoints using Swagger UI
4. Review the unit tests to understand testing patterns
5. Start building the MVC front-end (Part 3)

---

For questions or issues, refer to the project documentation or contact the development team.
