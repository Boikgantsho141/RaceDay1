@echo off
REM RaceDay API - Complete Startup Script for Command Prompt
REM This script will set up and run the API completely

setlocal enabledelayedexpansion

echo.
echo ==========================================
echo    RaceDay API - Complete Setup & Run
echo ==========================================
echo.

REM Step 1: Verify .NET installation
echo [1/5] Checking .NET installation...
dotnet --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: .NET is not installed or not in PATH
    echo Download from: https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)
echo ? .NET is installed
echo.

REM Step 2: Navigate to project directory
echo [2/5] Navigating to project directory...
cd /d "C:\Users\Student\source\repos\WebApplication2\WebApplication2"
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Could not navigate to project directory
    echo Expected path: C:\Users\Student\source\repos\WebApplication2\WebApplication2
    pause
    exit /b 1
)
echo Current directory: %cd%
echo ? In correct project directory
echo.

REM Step 3: Verify Program.cs exists
echo [3/5] Verifying project files...
if not exist "Program.cs" (
    echo ERROR: Program.cs not found in current directory
    echo Current directory: %cd%
    echo.
    echo Please navigate to the WebApplication2 folder (with Program.cs)
    pause
    exit /b 1
)
if not exist "appsettings.json" (
    echo ERROR: appsettings.json not found
    pause
    exit /b 1
)
echo ? Project files verified
echo.

REM Step 4: Restore packages
echo [4/5] Restoring NuGet packages...
dotnet restore
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Package restore failed
    echo Try running: dotnet nuget locals all --clear
    pause
    exit /b 1
)
echo ? Packages restored successfully
echo.

REM Step 5: Build project
echo [5/5] Building project...
dotnet build
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Build failed
    echo Try running: dotnet clean
    pause
    exit /b 1
)
echo ? Build successful
echo.

REM Step 6: Setup database
echo [6/6] Setting up database...
dotnet ef database update
if %ERRORLEVEL% NEQ 0 (
    echo WARNING: Database update had issues
    echo You may need to run migrations manually
)
echo ? Database setup complete
echo.

REM Step 7: Start API
echo ==========================================
echo    Starting RaceDay API Server
echo ==========================================
echo.
echo The API server is starting...
echo.
echo APIs will be available at:
echo   HTTP:  http://localhost:5014
echo   HTTPS: https://localhost:7071
echo.
echo Swagger UI: http://localhost:5014/swagger/index.html
echo.
echo NOTE: Open the browser to the Swagger URL above to test the API
echo.
echo Press Ctrl+C to stop the server
echo.
echo ==========================================
echo.

dotnet run

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: API failed to start
    echo Please check the error messages above
    pause
)

exit /b %ERRORLEVEL%
