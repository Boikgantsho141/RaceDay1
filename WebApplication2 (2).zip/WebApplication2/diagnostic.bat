@echo off
REM RaceDay API - Quick Diagnostic Script
REM This script checks if everything is set up correctly

echo.
echo ========================================
echo RaceDay API - Diagnostic Check
echo ========================================
echo.

REM Check 1: .NET is installed
echo [1/7] Checking .NET installation...
dotnet --version
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: .NET is not installed or not in PATH
    echo Download from: https://dotnet.microsoft.com/download/dotnet/8.0
    goto end
)
echo ? .NET is installed
echo.

REM Check 2: Project directory
echo [2/7] Checking project directory...
if exist Program.cs (
    echo ? Program.cs found
) else (
    echo ERROR: Program.cs not found
    echo Make sure you're in: WebApplication2 directory
    goto end
)
echo.

REM Check 3: appsettings.json
echo [3/7] Checking configuration...
if exist appsettings.json (
    echo ? appsettings.json found
) else (
    echo ERROR: appsettings.json not found
    goto end
)
echo.

REM Check 4: SQL Server LocalDB
echo [4/7] Checking SQL Server LocalDB...
sqllocaldb info 2>nul
if %ERRORLEVEL% EQU 0 (
    echo ? SQL Server LocalDB is installed
) else (
    echo WARNING: SQL Server LocalDB not found
    echo Download from: https://www.microsoft.com/en-us/sql-server/sql-server-express
)
echo.

REM Check 5: Restore packages
echo [5/7] Restoring NuGet packages...
dotnet restore --quiet
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Package restore failed
    echo Try: dotnet nuget locals all --clear
    goto end
)
echo ? Packages restored
echo.

REM Check 6: Build
echo [6/7] Building solution...
dotnet build --quiet 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Build failed
    echo Try running: dotnet clean ^&^& dotnet build
    goto end
)
echo ? Build successful
echo.

REM Check 7: Database
echo [7/7] Checking database...
dotnet ef database update --quiet 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo WARNING: Database update had issues
    echo Try: dotnet ef database update
)
echo ? Database checked
echo.

echo ========================================
echo ? All checks passed!
echo ========================================
echo.
echo You can now run the API:
echo   dotnet run
echo.
echo Then open in browser:
echo   http://localhost:5014/swagger/index.html
echo.

goto end

:end
echo Press any key to exit...
pause >nul
