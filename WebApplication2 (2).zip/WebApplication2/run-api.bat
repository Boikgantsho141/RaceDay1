@echo off
REM RaceDay API - Quick Start Script
REM This script sets up and runs the API

echo.
echo ========================================
echo    RaceDay API - Quick Start
echo ========================================
echo.

REM Check if in correct directory
if not exist Program.cs (
    echo ERROR: Program.cs not found!
    echo Make sure you're in the WebApplication2 directory
    echo.
    echo Current directory: %cd%
    echo.
    echo Navigate to:
    echo   cd WebApplication2
    echo.
    pause
    exit /b 1
)

echo [1/4] Restoring packages...
dotnet restore
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to restore packages
    pause
    exit /b 1
)
echo ? Packages restored
echo.

echo [2/4] Building solution...
dotnet build
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Build failed
    pause
    exit /b 1
)
echo ? Build successful
echo.

echo [3/4] Creating database...
dotnet ef database update
if %ERRORLEVEL% NEQ 0 (
    echo WARNING: Database creation had issues
    echo You may need to run: dotnet ef database update manually
)
echo ? Database ready
echo.

echo [4/4] Starting API...
echo.
echo ========================================
echo Starting API server...
echo ========================================
echo.
echo The API will be available at:
echo   HTTP:  http://localhost:5014
echo   HTTPS: https://localhost:7071
echo.
echo Open in browser:
echo   http://localhost:5014/swagger/index.html
echo.
echo Press Ctrl+C to stop the server
echo.
echo ========================================
echo.

dotnet run

pause
