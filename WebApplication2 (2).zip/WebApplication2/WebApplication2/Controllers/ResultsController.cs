using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [ApiController]
    [Route("api/events/{eventId}/results")]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly ILogger<ResultsController> _logger;

        public ResultsController(RaceDayDbContext context, ILogger<ResultsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        private bool IsAuthenticated()
        {
            return HttpContext.Session.GetInt32("UserId") != null;
        }

        private int GetCurrentUserId()
        {
            return HttpContext.Session.GetInt32("UserId") ?? 0;
        }

        private string? GetCurrentUserRole()
        {
            return HttpContext.Session.GetString("UserRole");
        }

        /// <summary>
        /// Get all results for an event (Organiser only)
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<List<ResultResponseDto>>> GetResultsByEvent(int eventId)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can view all results");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return NotFound("Event not found");

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return Forbid("You can only view results for your own events");

            var results = await _context.Results
                .Where(r => r.EventId == eventId)
                .OrderBy(r => r.FinishingPosition)
                .ToListAsync();

            return Ok(results.Select(r => new ResultResponseDto
            {
                Id = r.Id,
                ParticipantId = r.ParticipantId,
                EventId = r.EventId,
                FinishTime = r.FinishTime,
                FinishingPosition = r.FinishingPosition,
                RecordedAt = r.RecordedAt
            }).ToList());
        }

        /// <summary>
        /// Get a specific result
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<ResultResponseDto>> GetResultById(int eventId, int id)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            var result = await _context.Results
                .FirstOrDefaultAsync(r => r.Id == id && r.EventId == eventId);

            if (result == null)
                return NotFound("Result not found");

            var currentUserId = GetCurrentUserId();
            var currentUserRole = GetCurrentUserRole();

            // Allow access if it's the participant or the organiser
            if (result.ParticipantId != currentUserId)
            {
                var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
                if (eventEntity == null || eventEntity.OrganiserId != currentUserId)
                    return Forbid("Access denied");
            }

            return Ok(new ResultResponseDto
            {
                Id = result.Id,
                ParticipantId = result.ParticipantId,
                EventId = result.EventId,
                FinishTime = result.FinishTime,
                FinishingPosition = result.FinishingPosition,
                RecordedAt = result.RecordedAt
            });
        }

        /// <summary>
        /// Get participant's results for an event
        /// </summary>
        [HttpGet("participant/{participantId}")]
        public async Task<ActionResult<List<ResultResponseDto>>> GetParticipantResults(int eventId, int participantId)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            var currentUserId = GetCurrentUserId();
            var currentUserRole = GetCurrentUserRole();

            // Allow access if it's the participant or the organiser of the event
            if (participantId != currentUserId)
            {
                var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
                if (eventEntity == null || eventEntity.OrganiserId != currentUserId)
                    return Forbid("Access denied");
            }

            var results = await _context.Results
                .Where(r => r.EventId == eventId && r.ParticipantId == participantId)
                .ToListAsync();

            return Ok(results.Select(r => new ResultResponseDto
            {
                Id = r.Id,
                ParticipantId = r.ParticipantId,
                EventId = r.EventId,
                FinishTime = r.FinishTime,
                FinishingPosition = r.FinishingPosition,
                RecordedAt = r.RecordedAt
            }).ToList());
        }

        /// <summary>
        /// Create a result for a participant (Organiser only)
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<ResultResponseDto>> CreateResult(int eventId, [FromBody] CreateResultDto createDto)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can record results");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return NotFound("Event not found");

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return Forbid("You can only record results for your own events");

            // Check if participant exists and is enrolled
            var participant = await _context.Users.FirstOrDefaultAsync(u => u.Id == createDto.ParticipantId);
            if (participant == null)
                return NotFound("Participant not found");

            var enrolment = await _context.EventEnrolments
                .FirstOrDefaultAsync(e => e.ParticipantId == createDto.ParticipantId && e.EventId == eventId);
            if (enrolment == null)
                return BadRequest("Participant is not enrolled in this event");

            // Check if result already exists
            var existingResult = await _context.Results
                .FirstOrDefaultAsync(r => r.ParticipantId == createDto.ParticipantId && r.EventId == eventId);
            if (existingResult != null)
                return BadRequest("Result already exists for this participant");

            var result = new Result
            {
                ParticipantId = createDto.ParticipantId,
                EventId = eventId,
                FinishTime = createDto.FinishTime,
                FinishingPosition = createDto.FinishingPosition,
                RecordedAt = DateTime.UtcNow
            };

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Result recorded for participant {createDto.ParticipantId} in event {eventId}");

            return CreatedAtAction(nameof(GetResultById), new { eventId, id = result.Id }, new ResultResponseDto
            {
                Id = result.Id,
                ParticipantId = result.ParticipantId,
                EventId = result.EventId,
                FinishTime = result.FinishTime,
                FinishingPosition = result.FinishingPosition,
                RecordedAt = result.RecordedAt
            });
        }

        /// <summary>
        /// Update a result (Organiser only)
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateResult(int eventId, int id, [FromBody] CreateResultDto updateDto)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can update results");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return NotFound("Event not found");

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return Forbid("You can only update results for your own events");

            var result = await _context.Results
                .FirstOrDefaultAsync(r => r.Id == id && r.EventId == eventId);
            if (result == null)
                return NotFound("Result not found");

            result.FinishTime = updateDto.FinishTime;
            result.FinishingPosition = updateDto.FinishingPosition;

            _context.Results.Update(result);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Result {id} updated for event {eventId}");

            return Ok(new ResultResponseDto
            {
                Id = result.Id,
                ParticipantId = result.ParticipantId,
                EventId = result.EventId,
                FinishTime = result.FinishTime,
                FinishingPosition = result.FinishingPosition,
                RecordedAt = result.RecordedAt
            });
        }

        /// <summary>
        /// Delete a result (Organiser only)
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteResult(int eventId, int id)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can delete results");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return NotFound("Event not found");

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return Forbid("You can only delete results for your own events");

            var result = await _context.Results
                .FirstOrDefaultAsync(r => r.Id == id && r.EventId == eventId);
            if (result == null)
                return NotFound("Result not found");

            _context.Results.Remove(result);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Result {id} deleted from event {eventId}");

            return Ok("Result deleted successfully");
        }
    }
}
