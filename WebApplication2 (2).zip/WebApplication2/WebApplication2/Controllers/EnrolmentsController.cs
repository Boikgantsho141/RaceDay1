using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [ApiController]
    [Route("api/events/{eventId}/enrolments")]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly ILogger<EnrolmentsController> _logger;

        public EnrolmentsController(RaceDayDbContext context, ILogger<EnrolmentsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        private bool IsAuthenticated()
        {
            return HttpContext.Session.GetInt32("UserId") != null;
        }

        private int GetCurrentUserId()
        {
            return HttpContext.Session.GetInt32("UserId") ?? 0;
        }

        private string? GetCurrentUserRole()
        {
            return HttpContext.Session.GetString("UserRole");
        }

        /// <summary>
        /// Get all enrolments for an event (Organiser only)
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<List<EventEnrolmentResponseDto>>> GetEnrolmentsByEvent(int eventId)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can view all enrolments");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return NotFound("Event not found");

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return Forbid("You can only view enrolments for your own events");

            var enrolments = await _context.EventEnrolments
                .Where(e => e.EventId == eventId)
                .ToListAsync();

            return Ok(enrolments.Select(e => new EventEnrolmentResponseDto
            {
                Id = e.Id,
                ParticipantId = e.ParticipantId,
                EventId = e.EventId,
                CategoryId = e.CategoryId,
                EnrolledAt = e.EnrolledAt
            }).ToList());
        }

        /// <summary>
        /// Get participant's enrolments for an event
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<EventEnrolmentResponseDto>> GetEnrolmentById(int eventId, int id)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            var enrolment = await _context.EventEnrolments
                .FirstOrDefaultAsync(e => e.Id == id && e.EventId == eventId);

            if (enrolment == null)
                return NotFound("Enrolment not found");

            // Allow access if it's the participant or if they're the organiser of the event
            var currentUserId = GetCurrentUserId();
            if (enrolment.ParticipantId != currentUserId)
            {
                var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
                if (eventEntity == null || eventEntity.OrganiserId != currentUserId)
                    return Forbid("Access denied");
            }

            return Ok(new EventEnrolmentResponseDto
            {
                Id = enrolment.Id,
                ParticipantId = enrolment.ParticipantId,
                EventId = enrolment.EventId,
                CategoryId = enrolment.CategoryId,
                EnrolledAt = enrolment.EnrolledAt
            });
        }

        /// <summary>
        /// Enrol in an event (Participant only)
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<EventEnrolmentResponseDto>> EnrolInEvent(int eventId, [FromBody] EnrollEventDto enrollDto)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Participant.ToString())
                return Forbid("Only participants can enrol in events");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return NotFound("Event not found");

            var category = await _context.Categories.FirstOrDefaultAsync(c => c.Id == enrollDto.CategoryId && c.EventId == eventId);
            if (category == null)
                return NotFound("Category not found");

            // Check if already enrolled
            var existingEnrolment = await _context.EventEnrolments
                .FirstOrDefaultAsync(e => e.ParticipantId == GetCurrentUserId() && e.EventId == eventId);

            if (existingEnrolment != null)
                return BadRequest("Already enrolled in this event");

            var enrolment = new EventEnrolment
            {
                ParticipantId = GetCurrentUserId(),
                EventId = eventId,
                CategoryId = enrollDto.CategoryId,
                EnrolledAt = DateTime.UtcNow
            };

            _context.EventEnrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Participant {GetCurrentUserId()} enrolled in event {eventId}");

            return CreatedAtAction(nameof(GetEnrolmentById), new { eventId, id = enrolment.Id }, new EventEnrolmentResponseDto
            {
                Id = enrolment.Id,
                ParticipantId = enrolment.ParticipantId,
                EventId = enrolment.EventId,
                CategoryId = enrolment.CategoryId,
                EnrolledAt = enrolment.EnrolledAt
            });
        }

        /// <summary>
        /// Cancel enrolment (Participant only)
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> CancelEnrolment(int eventId, int id)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            var enrolment = await _context.EventEnrolments
                .FirstOrDefaultAsync(e => e.Id == id && e.EventId == eventId);

            if (enrolment == null)
                return NotFound("Enrolment not found");

            if (enrolment.ParticipantId != GetCurrentUserId())
                return Forbid("You can only cancel your own enrolments");

            _context.EventEnrolments.Remove(enrolment);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Participant {GetCurrentUserId()} cancelled enrolment {id}");

            return Ok("Enrolment cancelled successfully");
        }
    }
}
