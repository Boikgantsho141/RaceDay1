using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [ApiController]
    [Route("api/events/{eventId}/categories")]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly ILogger<CategoriesController> _logger;

        public CategoriesController(RaceDayDbContext context, ILogger<CategoriesController> logger)
        {
            _context = context;
            _logger = logger;
        }

        private bool IsAuthenticated()
        {
            return HttpContext.Session.GetInt32("UserId") != null;
        }

        private int GetCurrentUserId()
        {
            return HttpContext.Session.GetInt32("UserId") ?? 0;
        }

        private string? GetCurrentUserRole()
        {
            return HttpContext.Session.GetString("UserRole");
        }

        private async Task<Event?> GetEventIfOwner(int eventId)
        {
            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return null;

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return null;

            return eventEntity;
        }

        /// <summary>
        /// Get all categories for an event (public endpoint)
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<List<CategoryResponseDto>>> GetCategoriesByEvent(int eventId)
        {
            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == eventId);
            if (eventEntity == null)
                return NotFound("Event not found");

            var categories = await _context.Categories.Where(c => c.EventId == eventId).ToListAsync();
            return Ok(categories.Select(c => new CategoryResponseDto
            {
                Id = c.Id,
                Name = c.Name,
                Description = c.Description,
                EventId = c.EventId
            }).ToList());
        }

        /// <summary>
        /// Get category by ID (public endpoint)
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<CategoryResponseDto>> GetCategoryById(int eventId, int id)
        {
            var category = await _context.Categories.FirstOrDefaultAsync(c => c.Id == id && c.EventId == eventId);
            if (category == null)
                return NotFound("Category not found");

            return Ok(new CategoryResponseDto
            {
                Id = category.Id,
                Name = category.Name,
                Description = category.Description,
                EventId = category.EventId
            });
        }

        /// <summary>
        /// Create a category for an event (Organiser only, must own the event)
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<CategoryResponseDto>> CreateCategory(int eventId, [FromBody] CreateCategoryDto createDto)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can create categories");

            var eventEntity = await GetEventIfOwner(eventId);
            if (eventEntity == null)
                return NotFound("Event not found or access denied");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var category = new Category
            {
                Name = createDto.Name,
                Description = createDto.Description,
                EventId = eventId,
                CreatedAt = DateTime.UtcNow
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Category '{category.Name}' created for event {eventId}");

            return CreatedAtAction(nameof(GetCategoryById), new { eventId, id = category.Id }, new CategoryResponseDto
            {
                Id = category.Id,
                Name = category.Name,
                Description = category.Description,
                EventId = category.EventId
            });
        }

        /// <summary>
        /// Update a category (Organiser only, must own the event)
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCategory(int eventId, int id, [FromBody] CreateCategoryDto updateDto)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can update categories");

            var eventEntity = await GetEventIfOwner(eventId);
            if (eventEntity == null)
                return NotFound("Event not found or access denied");

            var category = await _context.Categories.FirstOrDefaultAsync(c => c.Id == id && c.EventId == eventId);
            if (category == null)
                return NotFound("Category not found");

            category.Name = updateDto.Name;
            category.Description = updateDto.Description;

            _context.Categories.Update(category);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Category {id} updated for event {eventId}");

            return Ok(new CategoryResponseDto
            {
                Id = category.Id,
                Name = category.Name,
                Description = category.Description,
                EventId = category.EventId
            });
        }

        /// <summary>
        /// Delete a category (Organiser only, must own the event)
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategory(int eventId, int id)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can delete categories");

            var eventEntity = await GetEventIfOwner(eventId);
            if (eventEntity == null)
                return NotFound("Event not found or access denied");

            var category = await _context.Categories.FirstOrDefaultAsync(c => c.Id == id && c.EventId == eventId);
            if (category == null)
                return NotFound("Category not found");

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Category {id} deleted from event {eventId}");

            return Ok("Category deleted successfully");
        }
    }
}
