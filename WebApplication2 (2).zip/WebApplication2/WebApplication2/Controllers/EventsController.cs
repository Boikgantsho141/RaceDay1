using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.DTOs;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly ILogger<EventsController> _logger;

        public EventsController(RaceDayDbContext context, ILogger<EventsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        private bool IsAuthenticated()
        {
            return HttpContext.Session.GetInt32("UserId") != null;
        }

        private int GetCurrentUserId()
        {
            return HttpContext.Session.GetInt32("UserId") ?? 0;
        }

        private string? GetCurrentUserRole()
        {
            return HttpContext.Session.GetString("UserRole");
        }

        /// <summary>
        /// Get all events (public endpoint)
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<List<EventResponseDto>>> GetAllEvents()
        {
            var events = await _context.Events.ToListAsync();
            return Ok(events.Select(e => new EventResponseDto
            {
                Id = e.Id,
                Name = e.Name,
                Description = e.Description,
                EventDate = e.EventDate,
                Location = e.Location,
                Distance = e.Distance,
                EventType = e.EventType,
                OrganiserId = e.OrganiserId,
                CreatedAt = e.CreatedAt
            }).ToList());
        }

        /// <summary>
        /// Get event by ID (public endpoint)
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<EventResponseDto>> GetEventById(int id)
        {
            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == id);
            if (eventEntity == null)
                return NotFound("Event not found");

            return Ok(new EventResponseDto
            {
                Id = eventEntity.Id,
                Name = eventEntity.Name,
                Description = eventEntity.Description,
                EventDate = eventEntity.EventDate,
                Location = eventEntity.Location,
                Distance = eventEntity.Distance,
                EventType = eventEntity.EventType,
                OrganiserId = eventEntity.OrganiserId,
                CreatedAt = eventEntity.CreatedAt
            });
        }

        /// <summary>
        /// Create a new event (Organiser only)
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<EventResponseDto>> CreateEvent([FromBody] CreateEventDto createDto)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can create events");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var eventEntity = new Event
            {
                Name = createDto.Name,
                Description = createDto.Description,
                EventDate = createDto.EventDate,
                Location = createDto.Location,
                Distance = createDto.Distance,
                EventType = createDto.EventType,
                OrganiserId = GetCurrentUserId(),
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Events.Add(eventEntity);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Event '{eventEntity.Name}' created by organiser {GetCurrentUserId()}");

            return CreatedAtAction(nameof(GetEventById), new { id = eventEntity.Id }, new EventResponseDto
            {
                Id = eventEntity.Id,
                Name = eventEntity.Name,
                Description = eventEntity.Description,
                EventDate = eventEntity.EventDate,
                Location = eventEntity.Location,
                Distance = eventEntity.Distance,
                EventType = eventEntity.EventType,
                OrganiserId = eventEntity.OrganiserId,
                CreatedAt = eventEntity.CreatedAt
            });
        }

        /// <summary>
        /// Update an event (Organiser only, must own the event)
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] UpdateEventDto updateDto)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can update events");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == id);
            if (eventEntity == null)
                return NotFound("Event not found");

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return Forbid("You can only update your own events");

            eventEntity.Name = updateDto.Name;
            eventEntity.Description = updateDto.Description;
            eventEntity.EventDate = updateDto.EventDate;
            eventEntity.Location = updateDto.Location;
            eventEntity.Distance = updateDto.Distance;
            eventEntity.EventType = updateDto.EventType;
            eventEntity.UpdatedAt = DateTime.UtcNow;

            _context.Events.Update(eventEntity);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Event {id} updated by organiser {GetCurrentUserId()}");

            return Ok(new EventResponseDto
            {
                Id = eventEntity.Id,
                Name = eventEntity.Name,
                Description = eventEntity.Description,
                EventDate = eventEntity.EventDate,
                Location = eventEntity.Location,
                Distance = eventEntity.Distance,
                EventType = eventEntity.EventType,
                OrganiserId = eventEntity.OrganiserId,
                CreatedAt = eventEntity.CreatedAt
            });
        }

        /// <summary>
        /// Delete an event (Organiser only, must own the event)
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (!IsAuthenticated())
                return Unauthorized("Not authenticated");

            if (GetCurrentUserRole() != UserRole.Organiser.ToString())
                return Forbid("Only organisers can delete events");

            var eventEntity = await _context.Events.FirstOrDefaultAsync(e => e.Id == id);
            if (eventEntity == null)
                return NotFound("Event not found");

            if (eventEntity.OrganiserId != GetCurrentUserId())
                return Forbid("You can only delete your own events");

            _context.Events.Remove(eventEntity);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Event {id} deleted by organiser {GetCurrentUserId()}");

            return Ok("Event deleted successfully");
        }
    }
}
