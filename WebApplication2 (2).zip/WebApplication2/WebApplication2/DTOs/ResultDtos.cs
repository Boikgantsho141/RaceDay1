namespace WebApplication2.DTOs
{
    public class CreateResultDto
    {
        public int ParticipantId { get; set; }
        public TimeSpan FinishTime { get; set; }
        public int FinishingPosition { get; set; }
    }

    public class ResultResponseDto
    {
        public int Id { get; set; }
        public int ParticipantId { get; set; }
        public int EventId { get; set; }
        public TimeSpan FinishTime { get; set; }
        public int FinishingPosition { get; set; }
        public DateTime RecordedAt { get; set; }
    }
}
