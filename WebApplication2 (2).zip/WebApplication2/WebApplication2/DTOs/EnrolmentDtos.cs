namespace WebApplication2.DTOs
{
    public class EnrollEventDto
    {
        public int CategoryId { get; set; }
    }

    public class EventEnrolmentResponseDto
    {
        public int Id { get; set; }
        public int ParticipantId { get; set; }
        public int EventId { get; set; }
        public int CategoryId { get; set; }
        public DateTime EnrolledAt { get; set; }
    }
}
