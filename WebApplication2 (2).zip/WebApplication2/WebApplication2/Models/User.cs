namespace WebApplication2.Models
{
    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public UserRole Role { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public ICollection<EventEnrolment> EventEnrolments { get; set; } = new List<EventEnrolment>();
        public ICollection<Result> Results { get; set; } = new List<Result>();
    }

    public enum UserRole
    {
        Organiser,
        Participant
    }
}
