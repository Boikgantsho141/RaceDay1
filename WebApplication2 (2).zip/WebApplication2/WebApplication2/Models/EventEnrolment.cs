namespace WebApplication2.Models
{
    public class EventEnrolment
    {
        public int Id { get; set; }
        public int ParticipantId { get; set; }
        public int EventId { get; set; }
        public int CategoryId { get; set; }
        public DateTime EnrolledAt { get; set; }

        public User Participant { get; set; } = null!;
        public Event Event { get; set; } = null!;
        public Category Category { get; set; } = null!;
    }
}
