namespace WebApplication2.Models
{
    public class Result
    {
        public int Id { get; set; }
        public int ParticipantId { get; set; }
        public int EventId { get; set; }
        public TimeSpan FinishTime { get; set; }
        public int FinishingPosition { get; set; }
        public DateTime RecordedAt { get; set; }

        public User Participant { get; set; } = null!;
        public Event Event { get; set; } = null!;
    }
}
