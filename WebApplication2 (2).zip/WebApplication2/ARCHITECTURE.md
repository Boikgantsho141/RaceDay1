# RaceDay API - Project Architecture

## Overview

The RaceDay API follows a layered architecture pattern with clear separation of concerns:

```
Presentation Layer (Controllers)
    ?
Business Logic Layer (Services)
    ?
Data Access Layer (DbContext, Models)
    ?
Database (SQL Server)
```

## Project Structure

```
WebApplication2/
??? Controllers/
?   ??? AuthController.cs          # Authentication endpoints
?   ??? UsersController.cs         # User profile management
?   ??? EventsController.cs        # Event management
?   ??? CategoriesController.cs    # Category management
?   ??? EnrolmentsController.cs    # Event enrolments
?   ??? ResultsController.cs       # Race results
?
??? Models/
?   ??? User.cs                    # User entity (Organiser/Participant)
?   ??? Event.cs                   # Event entity
?   ??? Category.cs                # Event category entity
?   ??? EventEnrolment.cs          # Participant enrolment
?   ??? Result.cs                  # Race result entity
?
??? DTOs/
?   ??? AuthDtos.cs                # Authentication DTOs
?   ??? EventDtos.cs               # Event DTOs
?   ??? CategoryDtos.cs            # Category DTOs
?   ??? EnrolmentDtos.cs           # Enrolment DTOs
?   ??? ResultDtos.cs              # Result DTOs
?
??? Data/
?   ??? RaceDayDbContext.cs        # Entity Framework DbContext
?
??? Services/
?   ??? AuthenticationService.cs   # Password hashing service
?
??? Program.cs                      # Application startup
??? appsettings.json               # Configuration

WebApplication2.Tests/
??? Controllers/
?   ??? AuthControllerTests.cs
?   ??? EventsControllerTests.cs
?   ??? EnrolmentsControllerTests.cs
?   ??? ResultsControllerTests.cs
?
??? Services/
?   ??? AuthenticationServiceTests.cs
?
??? Data/
    ??? RaceDayDbContextTests.cs
```

## Design Patterns

### 1. Repository Pattern (implicit)
The DbContext acts as a repository, providing access to the database.

```csharp
// Controllers access data through injected DbContext
public class EventsController : ControllerBase
{
    private readonly RaceDayDbContext _context;
    
    public EventsController(RaceDayDbContext context)
    {
        _context = context;
    }
}
```

### 2. Dependency Injection
Services are registered in `Program.cs` and injected into controllers:

```csharp
builder.Services.AddScoped<IAuthenticationService, AuthenticationService>();
builder.Services.AddDbContext<RaceDayDbContext>(options =>
    options.UseSqlServer(connectionString));
```

### 3. DTO Pattern
Data Transfer Objects separate internal models from API contracts:

```csharp
// Internal model
public class User { ... }

// API DTO
public class UserProfileDto { ... }
```

### 4. Service Injection
Business logic is encapsulated in services:

```csharp
public class AuthenticationService : IAuthenticationService
{
    public string HashPassword(string password) { ... }
    public bool VerifyPassword(string password, string hash) { ... }
}
```

## Authentication & Authorization Flow

```
1. User Registration
   ?? Email validated
   ?? Password hashed with SHA256
   ?? User saved to database
   
2. User Login
   ?? Email found in database
   ?? Password verified against hash
   ?? Session created
   ?? UserId, Email, Role stored in session
   
3. Protected Requests
   ?? Session checked
   ?? UserId retrieved from session
   ?? Role-based access control applied
   
4. Logout
   ?? Session cleared
```

## Session Management

Sessions are configured in `Program.cs`:

```csharp
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
```

### Session Data Structure
```csharp
// Stored in session
HttpContext.Session.SetInt32("UserId", user.Id);
HttpContext.Session.SetString("UserEmail", user.Email);
HttpContext.Session.SetString("UserRole", user.Role.ToString());
```

## Database Schema

### Entity Relationships

```
User (1) ???? (Many) Event
           organiser relationship

User (1) ???? (Many) EventEnrolment
           participant relationship

Event (1) ???? (Many) Category

Event (1) ???? (Many) EventEnrolment
Category (1) ???? (Many) EventEnrolment

Event (1) ???? (Many) Result
User (1) ???? (Many) Result
```

### Key Constraints

- **Users.Email**: Unique constraint ensures no duplicate emails
- **EventEnrolments**: Unique constraint on (ParticipantId, EventId)
- **Results**: Unique constraint on (EventId, ParticipantId)

## API Response Structure

### Success Response (200 OK)
```json
{
  "id": 1,
  "firstName": "John",
  "lastName": "Doe",
  ...
}
```

### Error Response (4xx/5xx)
```json
{
  "message": "Description of error"
}
```

## Role-Based Access Control

### Implementation Strategy

1. **Check Authentication**
   ```csharp
   if (!IsAuthenticated())
       return Unauthorized("Not authenticated");
   ```

2. **Get Current User Role**
   ```csharp
   var role = HttpContext.Session.GetString("UserRole");
   ```

3. **Verify Role Permission**
   ```csharp
   if (role != UserRole.Organiser.ToString())
       return Forbid("Only organisers can perform this action");
   ```

### Role Permissions Matrix

| Operation | Organiser | Participant |
|-----------|-----------|-------------|
| Create Event | ? | ? |
| Update Event | ? (own) | ? |
| Delete Event | ? (own) | ? |
| Create Category | ? (own event) | ? |
| View Events | ? | ? |
| Enrol in Event | ? | ? |
| View Enrolments | ? (own event) | ? (own) |
| Record Results | ? (own event) | ? |
| View Results | ? (own event) | ? (own) |

## Logging

Logging is configured in `appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

Controllers inject `ILogger<T>` to log important operations:

```csharp
_logger.LogInformation($"User {user.Email} registered successfully with role {user.Role}");
_logger.LogInformation($"Event '{eventEntity.Name}' created by organiser {GetCurrentUserId()}");
```

## Error Handling

### Controller-Level Error Handling

```csharp
// Authentication check
if (!IsAuthenticated())
    return Unauthorized("Not authenticated");

// Authorization check
if (role != expectedRole)
    return Forbid("Access denied");

// Not found
if (entity == null)
    return NotFound("Resource not found");

// Bad request
if (conditionInvalid)
    return BadRequest("Error message");
```

### Global Exception Handling

Currently implemented at controller level. For production, consider middleware:

```csharp
app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        // Handle exceptions
    });
});
```

## Testing Architecture

### Unit Test Structure

```csharp
public class AuthControllerTests
{
    // Setup
    private RaceDayDbContext CreateDbContext() { ... }
    private AuthController CreateAuthController() { ... }
    
    // Test methods following AAA pattern (Arrange, Act, Assert)
    [Fact]
    public async Task Register_WithValidData_ShouldCreateUser()
    {
        // Arrange
        var registerDto = new RegisterDto { ... };
        
        // Act
        var result = await controller.Register(registerDto);
        
        // Assert
        Assert.Equal("john@example.com", returnedUser.Email);
    }
}
```

### Testing Tools

- **xUnit**: Test framework
- **Moq**: Mocking library (for future use)
- **InMemory Database**: For isolated database tests

### Test Coverage Areas

1. **Authentication**
   - Registration with valid/invalid data
   - Login with correct/incorrect credentials
   - Session management

2. **Authorization**
   - Role-based access control
   - Resource ownership verification

3. **CRUD Operations**
   - Create operations return correct data
   - Update operations modify data
   - Delete operations remove data
   - Read operations return data

4. **Business Logic**
   - Password hashing and verification
   - Unique constraint enforcement
   - Relationship integrity

## Deployment Considerations

### Development
- Uses LocalDB for easy setup
- Swagger UI enabled
- Detailed logging

### Production
- Use full SQL Server instance
- Disable Swagger UI
- Configure HTTPS certificates
- Implement rate limiting
- Add API authentication (e.g., JWT tokens)
- Set up monitoring and logging
- Configure CORS appropriately
- Use environment-specific configuration

## Performance Optimization Opportunities

1. **Caching**
   - Cache event listings
   - Cache user profiles

2. **Query Optimization**
   - Use `.Include()` for eager loading
   - Add database indexes

3. **Pagination**
   - Implement for large result sets

4. **Async Operations**
   - Already implemented with `async/await`

## Security Considerations

1. **Password Hashing**: SHA256 (consider BCrypt in production)
2. **Session Security**: HttpOnly cookies
3. **CORS**: Currently allows all origins (configure for production)
4. **Input Validation**: Implemented at controller level
5. **Authorization**: Role-based checks on protected endpoints

## Scalability

Current implementation is suitable for:
- Up to 10,000 users
- Up to 1,000 concurrent sessions
- Hundreds of events

For larger scale:
- Implement caching layer (Redis)
- Add database replication
- Use load balancing
- Implement CDN for static content

## Monitoring & Diagnostics

- Application logs in `Logging` configuration
- SQL Server query tracking in Entity Framework
- HTTP request/response logging in middleware

## Future Enhancements

1. API versioning (v1, v2, etc.)
2. JWT token-based authentication
3. OAuth 2.0 integration
4. Email notifications
5. Advanced searching and filtering
6. Data export (CSV, PDF)
7. Performance caching
8. Rate limiting
9. GraphQL support
10. Real-time updates (SignalR)

---

This architecture provides a solid foundation for the RaceDay API while maintaining code quality, testability, and maintainability.
