# RaceDay RESTful API

A comprehensive ASP.NET Core Web API for managing race events, user authentication, event enrolments, and results tracking. The system supports two distinct user roles: Organisers and Participants.

## Features

### User Roles

#### **Organiser**
- Create, update, and delete events
- Define age/distance categories for events
- Record participant results (finish times and positions)
- View all enrolments and results for their events

#### **Participant**
- Register and maintain profile information
- Browse available events
- Enrol in events by selecting a category
- View personal results
- Cancel enrolments

### Core Functionality

- **Authentication & Authorization**: Session-based authentication with role-based access control
- **Password Security**: Passwords are hashed using SHA256
- **Event Management**: Create and manage race events (runs, walks, cycles)
- **Categories**: Define flexible categories for each event
- **Enrolments**: Track participant registrations for events
- **Results**: Record and view race results with finishing positions
- **Swagger Integration**: Interactive API documentation and testing

## Technology Stack

- **Framework**: ASP.NET Core 8.0
- **Database**: SQL Server with Entity Framework Core (Code-First)
- **Authentication**: Session-based with SHA256 password hashing
- **Testing**: xUnit with Moq
- **API Documentation**: Swagger/OpenAPI

## Getting Started

### Prerequisites

- Visual Studio 2022 or higher
- .NET 8.0 SDK
- SQL Server (LocalDB or full instance)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd WebApplication2
   ```

2. **Restore dependencies**
   ```bash
   dotnet restore
   ```

3. **Update the database connection string** in `appsettings.json`:
   ```json
   "ConnectionStrings": {
     "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=RaceDayDb;Trusted_Connection=true;"
   }
   ```

4. **Create the database** using Entity Framework Core migrations:
   ```bash
   cd WebApplication2
   dotnet ef database update
   ```

5. **Run the application**
   ```bash
   dotnet run
   ```

### HTTP Server Access

The API runs on **Kestrel** (ASP.NET Core's built-in HTTP server) and is available at:

- **HTTP:** `http://localhost:5014`
- **HTTPS:** `https://localhost:7071`
- **Swagger UI:** `http://localhost:5014/swagger/index.html`

See [HTTP_SERVER_CONFIGURATION.md](HTTP_SERVER_CONFIGURATION.md) for detailed HTTP server configuration options.

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/status` - Get current authentication status

### User Profile

- `GET /api/users/profile` - Get current user's profile
- `GET /api/users/{id}` - Get user by ID
- `PUT /api/users/profile` - Update current user's profile

### Events

- `GET /api/events` - Get all events (public)
- `GET /api/events/{id}` - Get event by ID (public)
- `POST /api/events` - Create event (Organiser only)
- `PUT /api/events/{id}` - Update event (Organiser only)
- `DELETE /api/events/{id}` - Delete event (Organiser only)

### Categories

- `GET /api/events/{eventId}/categories` - Get categories for an event (public)
- `GET /api/events/{eventId}/categories/{id}` - Get category by ID (public)
- `POST /api/events/{eventId}/categories` - Create category (Organiser only)
- `PUT /api/events/{eventId}/categories/{id}` - Update category (Organiser only)
- `DELETE /api/events/{eventId}/categories/{id}` - Delete category (Organiser only)

### Enrolments

- `GET /api/events/{eventId}/enrolments` - Get all enrolments (Organiser only)
- `GET /api/events/{eventId}/enrolments/{id}` - Get enrolment by ID
- `POST /api/events/{eventId}/enrolments` - Enrol in event (Participant only)
- `DELETE /api/events/{eventId}/enrolments/{id}` - Cancel enrolment (Participant only)

### Results

- `GET /api/events/{eventId}/results` - Get all results (Organiser only)
- `GET /api/events/{eventId}/results/{id}` - Get result by ID
- `GET /api/events/{eventId}/results/participant/{participantId}` - Get participant results
- `POST /api/events/{eventId}/results` - Record result (Organiser only)
- `PUT /api/events/{eventId}/results/{id}` - Update result (Organiser only)
- `DELETE /api/events/{eventId}/results/{id}` - Delete result (Organiser only)

## Usage Examples

### Register as Participant

```json
POST /api/auth/register
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "password": "SecurePassword123!",
  "role": 1
}
```

### Register as Organiser

```json
POST /api/auth/register
Content-Type: application/json

{
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "jane@example.com",
  "phoneNumber": "0987654321",
  "password": "SecurePassword123!",
  "role": 0
}
```

### Login

```json
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "SecurePassword123!"
}
```

### Create Event (Organiser)

```json
POST /api/events
Content-Type: application/json
Cookie: session_cookie

{
  "name": "City Marathon 2024",
  "description": "Annual city marathon event",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "Central Park",
  "distance": 42.2,
  "eventType": 0
}
```

## Running Tests

Run all unit tests:

```bash
dotnet test
```

Run tests with verbose output:

```bash
dotnet test --verbosity detailed
```

### Test Coverage

Tests cover:
- User registration and login
- Password hashing and verification
- Event CRUD operations
- Role-based access control
- Event enrolments
- Result recording
- Database relationships

## Database Schema

### Users
- Id (Primary Key)
- FirstName
- LastName
- Email (Unique)
- PhoneNumber
- PasswordHash
- Role (Organiser/Participant)
- CreatedAt
- UpdatedAt

### Events
- Id (Primary Key)
- Name
- Description
- EventDate
- Location
- Distance
- EventType (Run/Walk/Cycle)
- OrganiserId (Foreign Key)
- CreatedAt
- UpdatedAt

### Categories
- Id (Primary Key)
- Name
- Description
- EventId (Foreign Key)
- CreatedAt

### EventEnrolments
- Id (Primary Key)
- ParticipantId (Foreign Key)
- EventId (Foreign Key)
- CategoryId (Foreign Key)
- EnrolledAt

### Results
- Id (Primary Key)
- ParticipantId (Foreign Key)
- EventId (Foreign Key)
- FinishTime
- FinishingPosition
- RecordedAt

## CI/CD Pipeline

GitHub Actions workflow is configured to:
- Build the solution on every push
- Run all unit tests
- Report build status

See workflow file: `.github/workflows/build-and-test.yml`

## Authentication & Security

- **Session-Based Authentication**: Users maintain authenticated state via HTTP sessions
- **Password Hashing**: Passwords are hashed using SHA256
- **Role-Based Access Control**: Endpoints enforce role-based restrictions
- **CORS Configuration**: API allows cross-origin requests from any origin

## Swagger Documentation

When running the application in development mode, Swagger UI is available at:
`https://localhost:5001/swagger/index.html`

All endpoints are documented with:
- Clear descriptions
- Request/response schemas
- HTTP status codes
- Authorization requirements

## Troubleshooting

### Database Connection Issues
- Verify SQL Server (LocalDB) is running
- Check connection string in `appsettings.json`
- Run: `dotnet ef database update`

### Port Already in Use
- Change port in `Properties/launchSettings.json`
- Or stop the application using the port

### HTTPS Certificate Issues
- Run: `dotnet dev-certs https --trust`

## Project Structure

```
WebApplication2/
??? Controllers/           # API endpoints
??? Models/               # Data entities
??? DTOs/                 # Data transfer objects
??? Data/                 # DbContext
??? Services/             # Business logic
??? Properties/           # Launch settings
??? appsettings.json      # Configuration
??? Program.cs            # Startup configuration

WebApplication2.Tests/
??? Controllers/          # Controller tests
??? Services/             # Service tests
??? Data/                 # Data context tests
```

## Future Enhancements

- Email verification for registration
- Password reset functionality
- Advanced filtering and searching
- Pagination for large result sets
- Export results to CSV/PDF
- Event notifications
- Leaderboards and rankings
- Performance analytics

## License

This project is part of the RaceDay System coursework assignment.

## Support

For issues or questions, please refer to the project documentation or contact the development team.

---

**API Version**: 1.0.0  
**Last Updated**: 2024
