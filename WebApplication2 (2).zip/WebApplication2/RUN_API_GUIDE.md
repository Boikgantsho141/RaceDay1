# ?? How to Run Your RaceDay API - Complete Guide

## ? Code Status: Working Perfectly

Your code builds successfully with **no errors**. If it's not running, follow these steps.

---

## ? Fastest Way to Get It Running

### Option 1: Use the Quick Start Script (Easiest)

1. **Download the script** (already created: `run-api.bat`)
2. **Double-click** `run-api.bat` in your project root
3. **Done!** - It will set up and run everything automatically

---

### Option 2: Manual Steps (Recommended for Learning)

Open **Command Prompt** or **PowerShell** and run these commands:

```bash
# 1. Navigate to the project
cd C:\Users\Student\source\repos\WebApplication2\WebApplication2

# 2. Restore packages
dotnet restore

# 3. Build the project
dotnet build

# 4. Create the database
dotnet ef database update

# 5. Run the API
dotnet run
```

**Expected Output:**
```
Now listening on: https://localhost:7071
Now listening on: http://localhost:5014
Application started. Press Ctrl+C to exit.
```

---

### Option 3: Run from Visual Studio (Easiest for IDE Users)

1. **Open Visual Studio**
2. **Open** `WebApplication2.sln`
3. **Make sure** `WebApplication2` is set as "Startup Project"
   - Right-click ? "Set as Startup Project"
4. **Press** `F5` or click the green "Run" button
5. **Done!** - Swagger UI will open automatically

---

## ?? What You Need Before Running

### Check 1: .NET 8 is Installed

```bash
dotnet --version
```

Should show: `8.0.x` or higher

If not: Download from https://dotnet.microsoft.com/download/dotnet/8.0

### Check 2: SQL Server LocalDB is Installed

```bash
sqllocaldb info
```

Should show: `(localdb)\mssqllocaldb`

If not: 
1. Download SQL Server Express: https://www.microsoft.com/en-us/sql-server/sql-server-express
2. Choose "LocalDB" during installation
3. Restart your computer

### Check 3: You're in the Right Directory

```bash
# You should be in the WebApplication2 folder (with Program.cs)
dir Program.cs

# Should show:
# Mode                 LastWriteTime         Length Name
# ----                 -------------         ------ ----
# -a---          1/01/2024  12:00 AM           2500 Program.cs
```

If you see "File not found", navigate to:
```bash
cd C:\Users\Student\source\repos\WebApplication2\WebApplication2
```

---

## ?? Step-by-Step: From Zero to Running

### Step 1: Open Command Prompt

**Windows:**
1. Press `Windows Key + R`
2. Type `cmd`
3. Press `Enter`

Or in **Visual Studio**:
1. Go to: **View ? Terminal**

### Step 2: Navigate to Project

```bash
cd C:\Users\Student\source\repos\WebApplication2\WebApplication2
```

Verify by typing:
```bash
dir Program.cs
```

You should see `Program.cs` listed.

### Step 3: Restore NuGet Packages

```bash
dotnet restore
```

Wait for it to complete. You should see:
```
Restore completed in X.XX seconds.
```

### Step 4: Build the Project

```bash
dotnet build
```

You should see:
```
Build succeeded.
```

### Step 5: Create the Database

```bash
dotnet ef database update
```

You should see:
```
Done. No migrations to apply.
```

### Step 6: Run the API

```bash
dotnet run
```

You should see:
```
Now listening on: http://localhost:5014
Now listening on: https://localhost:7071
Application started. Press Ctrl+C to exit.
```

### Step 7: Open in Browser

Open a new browser tab and go to:
```
http://localhost:5014/swagger/index.html
```

You should see the **Swagger UI** with all your endpoints!

---

## ? What to Do After It's Running

### Test the API

1. In Swagger UI, click on any endpoint (e.g., `GET /api/events`)
2. Click "Try it out"
3. Click "Execute"
4. You should see a response!

### Example: Register a User

1. Find: `POST /api/auth/register`
2. Click "Try it out"
3. Replace the example with:
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "password": "Password123!",
  "role": 1
}
```
4. Click "Execute"
5. You should see a success response!

---

## ?? Troubleshooting

### Issue: "Cannot open database 'RaceDayDb'"

**Solution:**
```bash
# Make sure you ran this:
dotnet ef database update

# If it still fails, try:
dotnet ef database drop
dotnet ef database update
```

---

### Issue: "Address already in use"

**Solution - Windows:**
```bash
# Find process using port 5014
netstat -ano | findstr :5014

# Kill it (replace <PID> with the number shown)
taskkill /PID <PID> /F

# Then run:
dotnet run
```

**Solution - Mac/Linux:**
```bash
# Find process using port 5014
lsof -i :5014

# Kill it (replace <PID> with the number shown)
kill -9 <PID>

# Then run:
dotnet run
```

---

### Issue: "HTTPS certificate error"

**Solution:**
```bash
# Trust the development certificate
dotnet dev-certs https --trust

# Then run:
dotnet run
```

---

### Issue: "Build failed" or "Cannot find namespace"

**Solution:**
```bash
# Clean and restore
dotnet clean
dotnet restore

# Rebuild
dotnet build

# Run
dotnet run
```

---

### Issue: "Connection string 'DefaultConnection' not found"

**Solution:**
Check that `appsettings.json` contains:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=RaceDayDb;Trusted_Connection=true;"
  }
}
```

Make sure:
- File is named exactly: `appsettings.json`
- It's in the `WebApplication2` directory (not the parent)
- The connection string name is exactly: `DefaultConnection`

---

## ?? Verify Everything is Working

### ? Check 1: Build

```bash
dotnet build
# Should show: Build succeeded.
```

### ? Check 2: Database

```bash
dotnet ef database update
# Should show: Done. No migrations to apply.
```

### ? Check 3: API Runs

```bash
dotnet run
# Should show: Now listening on: http://localhost:5014
```

### ? Check 4: Access Swagger

Open browser:
```
http://localhost:5014/swagger/index.html
# Should show: Swagger UI with all endpoints
```

### ? Check 5: Test Endpoint

In Swagger:
1. Expand `/api/events` (GET)
2. Click "Try it out"
3. Click "Execute"
4. Should show: Response code 200 and empty array `[]`

---

## ?? Understanding the Setup

### Project Structure
```
WebApplication2/
??? Program.cs                 # Startup configuration (HTTP server setup)
??? appsettings.json          # Configuration (database connection)
??? Controllers/              # API endpoints
??? Models/                   # Data models
??? Data/RaceDayDbContext.cs  # Database context
??? ...
```

### How It Works

1. **Program.cs** starts the HTTP server (Kestrel)
2. Listens on ports 5014 (HTTP) and 7071 (HTTPS)
3. **appsettings.json** tells it where the database is
4. Creates database automatically if it doesn't exist
5. Swagger UI is available for testing

### The HTTP Server

- **Type**: Kestrel (ASP.NET Core's built-in HTTP server)
- **No external installation**: It comes with .NET
- **Ports**: 5014 (HTTP) and 7071 (HTTPS)
- **Automatic**: Runs when you execute `dotnet run`

---

## ?? Tips & Tricks

### Tip 1: Run Without Stopping on Errors

```bash
# If you want to keep running even if there are issues:
dotnet run --no-build
```

### Tip 2: Run on Specific Port

```bash
# Use custom port instead of 5014:
dotnet run --urls "http://localhost:9999"
```

### Tip 3: Run in Background (Windows)

```bash
# Start in background:
start dotnet run

# Then you can use the same terminal
```

### Tip 4: View Database (SQL Server Management Studio)

1. Connect to: `(localdb)\mssqllocaldb`
2. Database name: `RaceDayDb`
3. View tables and data

---

## ?? Quick Reference

### Commands Summary

| Task | Command |
|------|---------|
| Navigate to project | `cd WebApplication2` |
| Restore packages | `dotnet restore` |
| Build | `dotnet build` |
| Create database | `dotnet ef database update` |
| Run API | `dotnet run` |
| Access Swagger | `http://localhost:5014/swagger` |
| Stop API | `Ctrl + C` |
| Clean project | `dotnet clean` |

### Ports

| Service | URL | Use |
|---------|-----|-----|
| HTTP API | `http://localhost:5014` | Development |
| HTTPS API | `https://localhost:7071` | Testing secure connection |
| Swagger UI | `http://localhost:5014/swagger` | Testing endpoints |

---

## ?? Success Checklist

After following these steps, you should have:

- [ ] .NET 8 installed
- [ ] SQL Server LocalDB installed
- [ ] Navigated to correct directory
- [ ] Ran `dotnet restore`
- [ ] Ran `dotnet build` (succeeded)
- [ ] Ran `dotnet ef database update` (succeeded)
- [ ] Ran `dotnet run` (shows "Now listening on")
- [ ] Opened Swagger UI in browser
- [ ] Tested an endpoint (got a response)

If all checked: **?? Your API is running!**

---

## ?? Still Not Working?

### Try This in Order:

```bash
# 1. Complete reset
dotnet clean
del bin -r -force
del obj -r -force

# 2. Restore
dotnet restore

# 3. Build
dotnet build

# 4. Database
dotnet ef migrations add InitialCreate
dotnet ef database update

# 5. Run
dotnet run
```

If this doesn't work, check:
1. Are you in the `WebApplication2` directory (with Program.cs)?
2. Is .NET 8 installed? (`dotnet --version`)
3. Is SQL Server LocalDB installed? (`sqllocaldb info`)

---

## ?? Learn More

- **Troubleshooting:** See [TROUBLESHOOTING_GUIDE.md](TROUBLESHOOTING_GUIDE.md)
- **API Usage:** See [API_DOCUMENTATION.md](API_DOCUMENTATION.md)
- **Setup:** See [SETUP_GUIDE.md](SETUP_GUIDE.md)
- **HTTP Server:** See [HTTP_QUICK_CONNECT.md](HTTP_QUICK_CONNECT.md)

---

**Your API is ready to run! Follow the steps above and you'll have it working in minutes.** ??
