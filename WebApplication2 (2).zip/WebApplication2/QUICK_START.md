# RaceDay API - Getting Started Quick Reference

## ?? Quick Start (5 minutes)

### Prerequisites
- .NET 8.0 SDK installed
- SQL Server LocalDB (included with Visual Studio)
- Visual Studio 2022 or VS Code

### Setup Steps

```bash
# 1. Restore packages
dotnet restore

# 2. Create database
cd WebApplication2
dotnet ef database update

# 3. Run application
dotnet run

# 4. Open in browser
# https://localhost:5001/swagger/index.html
```

### Expected Output
```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: https://localhost:5001
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to exit.
```

---

## ?? Testing the API via Swagger UI

### Step 1: Register Users

**Register as Organiser:**
1. Go to `/api/auth/register`
2. Click "Try it out"
3. Enter:
```json
{
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "organiser@example.com",
  "phoneNumber": "1234567890",
  "password": "Password123!",
  "role": 0
}
```
4. Click "Execute"
5. Expected: 200 OK with user details

**Register as Participant:**
1. Same steps, but use:
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "participant@example.com",
  "phoneNumber": "0987654321",
  "password": "Password123!",
  "role": 1
}
```

### Step 2: Login

1. Go to `/api/auth/login`
2. Click "Try it out"
3. Enter organiser credentials:
```json
{
  "email": "organiser@example.com",
  "password": "Password123!"
}
```
4. Click "Execute"
5. Expected: 200 OK with user profile
6. **Note:** Session cookie is automatically set

### Step 3: Create Event (as Organiser)

1. Go to `POST /api/events`
2. Click "Try it out"
3. Enter:
```json
{
  "name": "City Marathon 2024",
  "description": "Annual city marathon event",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "Central Park",
  "distance": 42.2,
  "eventType": 0
}
```
4. Click "Execute"
5. Expected: 201 Created
6. Note the `id` in response (e.g., id: 1)

### Step 4: Create Category

1. Go to `POST /api/events/{eventId}/categories` (use id from Step 3)
2. Click "Try it out"
3. Enter eventId: `1`
4. Enter:
```json
{
  "name": "Adults (25-40)",
  "description": "For participants aged 25-40"
}
```
5. Click "Execute"
6. Expected: 201 Created
7. Note the category id

### Step 5: Logout & Login as Participant

1. Go to `POST /api/auth/logout`
2. Click "Execute" - Session cleared
3. Go to `POST /api/auth/login`
4. Login with participant email/password
5. Expected: 200 OK with participant profile

### Step 6: Enrol in Event (as Participant)

1. Go to `POST /api/events/{eventId}/enrolments`
2. Enter eventId: `1`
3. Enter:
```json
{
  "categoryId": 1
}
```
4. Click "Execute"
5. Expected: 201 Created with enrolment details

### Step 7: Login as Organiser & Record Result

1. Logout current session
2. Login as organiser
3. Go to `POST /api/events/{eventId}/results`
4. Enter eventId: `1`
5. Enter:
```json
{
  "participantId": 2,
  "finishTime": "02:45:30.0000000",
  "finishingPosition": 1
}
```
6. Click "Execute"
7. Expected: 201 Created

### Step 8: View Results

**As Organiser:** View all results
1. Go to `GET /api/events/{eventId}/results`
2. Enter eventId: `1`
3. Expected: 200 OK with results list

**As Participant:** View own results
1. Logout, login as participant
2. Go to `GET /api/events/{eventId}/results/participant/{participantId}`
3. Expected: 200 OK with own results

---

## ?? Running Tests

### Execute All Tests
```bash
dotnet test
```

### Expected Output
```
Starting test execution, please wait...
Test Run Successful.
Total tests: 50
     Passed: 50
     Failed: 0
     Skipped: 0
Test Run Duration: X.XXX Seconds
```

### Run Specific Test Class
```bash
dotnet test --filter ClassName=AuthControllerTests
```

### Run with Verbose Output
```bash
dotnet test --verbosity detailed
```

---

## ?? Testing via Command Line (curl)

### Register User
```bash
curl -X POST https://localhost:5001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName":"John",
    "lastName":"Doe",
    "email":"john@example.com",
    "phoneNumber":"1234567890",
    "password":"Password123!",
    "role":1
  }' --insecure
```

### Login
```bash
curl -X POST https://localhost:5001/api/auth/login \
  -H "Content-Type: application/json" \
  -c cookies.txt \
  -d '{
    "email":"john@example.com",
    "password":"Password123!"
  }' --insecure
```

### Get Profile
```bash
curl -X GET https://localhost:5001/api/users/profile \
  -b cookies.txt --insecure
```

---

## ?? API Response Examples

### 200 OK (Success)
```json
{
  "id": 1,
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "role": 1
}
```

### 201 Created (Resource Created)
```json
{
  "id": 1,
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "jane@example.com",
  "phoneNumber": "9876543210",
  "role": 0
}
```

### 401 Unauthorized
```json
{
  "message": "Not authenticated"
}
```

### 403 Forbidden
```json
{
  "message": "Only organisers can create events"
}
```

### 404 Not Found
```json
{
  "message": "Event not found"
}
```

### 400 Bad Request
```json
{
  "message": "Email already registered"
}
```

---

## ?? Authentication Flow

1. **Register** - Create account with role
2. **Login** - Get session cookie
3. **Use Cookie** - Session maintained for requests
4. **Role Check** - Endpoints verify role permission
5. **Logout** - Session cleared

---

## ?? Key Features to Test

### Organiser Features
- ? Create/Update/Delete events
- ? Create/Update/Delete categories
- ? View all enrolments for their events
- ? Record participant results
- ? View all results for their events

### Participant Features
- ? View all events
- ? View event categories
- ? Enrol in events with category selection
- ? Cancel enrolments
- ? View their own results
- ? Cannot access organiser-only endpoints

### Security Features
- ? Passwords hashed (not plaintext)
- ? Sessions expire after 30 minutes
- ? Role-based access enforced
- ? Resource ownership verified

---

## ?? Troubleshooting

### Issue: "Cannot connect to database"
```bash
# Solution: Create/update database
dotnet ef database update
```

### Issue: "Port 5001 already in use"
```bash
# Solution: Use different port
# Edit launchSettings.json or use:
dotnet run --urls "https://localhost:7000"
```

### Issue: "HTTPS certificate error"
```bash
# Solution: Trust local certificate
dotnet dev-certs https --trust
```

### Issue: "Tests fail"
```bash
# Solution: Ensure database is updated
dotnet ef database update

# Then run tests
dotnet test
```

---

## ?? Documentation Files

| File | Purpose |
|------|---------|
| README.md | Overview and quick start |
| SETUP_GUIDE.md | Detailed installation |
| API_DOCUMENTATION.md | Endpoint reference |
| ARCHITECTURE.md | System design |
| IMPLEMENTATION_SUMMARY.md | Completion status |
| SUBMISSION_CHECKLIST.md | Verification checklist |
| PROJECT_STRUCTURE.md | File layout |
| This file | Getting started guide |

---

## ?? Status Indicators

### When API Starts Successfully
```
? Application started
? Database connected
? Swagger available at /swagger/index.html
? All endpoints ready
```

### When Tests Pass
```
? 50 tests passed
? 0 tests failed
? All functionality working
```

---

## ?? Common Questions

**Q: Where do I test the API?**
A: Go to `https://localhost:5001/swagger/index.html`

**Q: How long does database setup take?**
A: Usually < 1 minute

**Q: Can I use Postman instead of Swagger?**
A: Yes, just use the same endpoints and send JSON bodies

**Q: How do I know if I'm logged in?**
A: Check `/api/auth/status` - returns user info if authenticated

**Q: What if I forget a password?**
A: Currently, only hashing is implemented. Password reset is a future enhancement.

**Q: How do sessions work across requests?**
A: Session cookie is automatically sent with each request. No manual header needed.

---

## ?? What You'll Learn

By following this guide and testing the API, you'll understand:
- ? RESTful API design
- ? Authentication and authorization
- ? Database relationships
- ? Entity Framework Core
- ? Session management
- ? Role-based access control
- ? API testing
- ? Unit testing

---

## ? Success Checklist

- [ ] API starts without errors
- [ ] Swagger UI loads at `/swagger/index.html`
- [ ] Can register as organiser
- [ ] Can register as participant
- [ ] Can login and maintain session
- [ ] Can create events as organiser
- [ ] Can create categories as organiser
- [ ] Can enrol in events as participant
- [ ] Can record results as organiser
- [ ] Can view results as participant
- [ ] All tests pass
- [ ] Cannot access endpoints without authentication
- [ ] Cannot access organiser endpoints as participant
- [ ] Cannot access participant endpoints as organiser

---

## ?? Ready to Go!

The RaceDay API is fully functional and ready for exploration. Start by registering users and testing the endpoints through Swagger UI.

**Happy testing! ??**
