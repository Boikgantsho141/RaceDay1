# RaceDay API Documentation

## Overview

The RaceDay API is a comprehensive REST API for managing race events, participants, and results. It features session-based authentication with role-based access control supporting two user types: Organisers and Participants.

## Authentication

### Login Flow

1. **Register** - Create a new account as either an Organiser or Participant
2. **Login** - Authenticate with email and password
3. **Session** - User session is maintained for subsequent requests
4. **Logout** - End the session

### User Roles

#### Organiser (Role: 0)
- Full control over events they create
- Can define categories for events
- Can record participant results
- Can view all enrolments for their events

#### Participant (Role: 1)
- Can browse and view all events
- Can view available categories
- Can enrol in events
- Can view their own results

## Detailed Endpoint Reference

### Authentication Endpoints

#### Register
```
POST /api/auth/register
Content-Type: application/json

Request:
{
  "firstName": "string",
  "lastName": "string",
  "email": "string (email format)",
  "phoneNumber": "string",
  "password": "string",
  "role": 0 or 1  // 0=Organiser, 1=Participant
}

Response: 200 OK
{
  "id": 1,
  "firstName": "string",
  "lastName": "string",
  "email": "string",
  "phoneNumber": "string",
  "role": 0 or 1
}

Response: 400 Bad Request
{
  "message": "Email already registered" or validation errors
}
```

#### Login
```
POST /api/auth/login
Content-Type: application/json

Request:
{
  "email": "string",
  "password": "string"
}

Response: 200 OK
{
  "id": 1,
  "firstName": "string",
  "lastName": "string",
  "email": "string",
  "phoneNumber": "string",
  "role": 0 or 1
}

Response: 401 Unauthorized
{
  "message": "Invalid email or password"
}
```

#### Logout
```
POST /api/auth/logout
Authorization: Session

Response: 200 OK
{
  "message": "Logged out successfully"
}
```

#### Check Authentication Status
```
GET /api/auth/status

Response: 200 OK
{
  "userId": 1,
  "email": "user@example.com",
  "role": "Participant"
}

Response: 401 Unauthorized
{
  "message": "Not authenticated"
}
```

### User Profile Endpoints

#### Get Current User Profile
```
GET /api/users/profile
Authorization: Session

Response: 200 OK
{
  "id": 1,
  "firstName": "string",
  "lastName": "string",
  "email": "string",
  "phoneNumber": "string",
  "role": 0 or 1
}

Response: 401 Unauthorized
```

#### Get User by ID
```
GET /api/users/{userId}
Authorization: Session

Response: 200 OK
{
  "id": 1,
  "firstName": "string",
  "lastName": "string",
  "email": "string",
  "phoneNumber": "string",
  "role": 0 or 1
}

Response: 401 Unauthorized or 403 Forbidden
```

#### Update User Profile
```
PUT /api/users/profile
Authorization: Session
Content-Type: application/json

Request:
{
  "firstName": "string",
  "lastName": "string",
  "phoneNumber": "string"
}

Response: 200 OK
{
  "id": 1,
  "firstName": "string",
  "lastName": "string",
  "email": "string",
  "phoneNumber": "string",
  "role": 0 or 1
}

Response: 401 Unauthorized or 404 Not Found
```

### Event Endpoints

#### List All Events
```
GET /api/events

Response: 200 OK
[
  {
    "id": 1,
    "name": "string",
    "description": "string",
    "eventDate": "2024-06-15T08:00:00Z",
    "location": "string",
    "distance": 42.2,
    "eventType": 0,  // 0=Run, 1=Walk, 2=Cycle
    "organiserId": 1,
    "createdAt": "2024-01-01T00:00:00Z"
  }
]
```

#### Get Event by ID
```
GET /api/events/{eventId}

Response: 200 OK
{
  "id": 1,
  "name": "string",
  "description": "string",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "string",
  "distance": 42.2,
  "eventType": 0,
  "organiserId": 1,
  "createdAt": "2024-01-01T00:00:00Z"
}

Response: 404 Not Found
```

#### Create Event (Organiser Only)
```
POST /api/events
Authorization: Session (Organiser)
Content-Type: application/json

Request:
{
  "name": "string",
  "description": "string",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "string",
  "distance": 42.2,
  "eventType": 0
}

Response: 201 Created
{
  "id": 1,
  "name": "string",
  "description": "string",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "string",
  "distance": 42.2,
  "eventType": 0,
  "organiserId": 1,
  "createdAt": "2024-01-01T00:00:00Z"
}

Response: 401 Unauthorized or 403 Forbidden
```

#### Update Event (Organiser Only)
```
PUT /api/events/{eventId}
Authorization: Session (Organiser)
Content-Type: application/json

Request:
{
  "name": "string",
  "description": "string",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "string",
  "distance": 42.2,
  "eventType": 0
}

Response: 200 OK
{
  "id": 1,
  "name": "string",
  ...
}

Response: 403 Forbidden (if not owner) or 404 Not Found
```

#### Delete Event (Organiser Only)
```
DELETE /api/events/{eventId}
Authorization: Session (Organiser)

Response: 200 OK
{
  "message": "Event deleted successfully"
}

Response: 403 Forbidden or 404 Not Found
```

### Category Endpoints

#### List Categories for Event
```
GET /api/events/{eventId}/categories

Response: 200 OK
[
  {
    "id": 1,
    "name": "string",
    "description": "string",
    "eventId": 1
  }
]

Response: 404 Not Found (event not found)
```

#### Get Category by ID
```
GET /api/events/{eventId}/categories/{categoryId}

Response: 200 OK
{
  "id": 1,
  "name": "string",
  "description": "string",
  "eventId": 1
}

Response: 404 Not Found
```

#### Create Category (Organiser Only)
```
POST /api/events/{eventId}/categories
Authorization: Session (Organiser)
Content-Type: application/json

Request:
{
  "name": "string",
  "description": "string"
}

Response: 201 Created
{
  "id": 1,
  "name": "string",
  "description": "string",
  "eventId": 1
}

Response: 401 Unauthorized or 403 Forbidden
```

#### Update Category (Organiser Only)
```
PUT /api/events/{eventId}/categories/{categoryId}
Authorization: Session (Organiser)
Content-Type: application/json

Request:
{
  "name": "string",
  "description": "string"
}

Response: 200 OK
{
  "id": 1,
  "name": "string",
  "description": "string",
  "eventId": 1
}
```

#### Delete Category (Organiser Only)
```
DELETE /api/events/{eventId}/categories/{categoryId}
Authorization: Session (Organiser)

Response: 200 OK
{
  "message": "Category deleted successfully"
}
```

### Enrolment Endpoints

#### List All Enrolments for Event (Organiser Only)
```
GET /api/events/{eventId}/enrolments
Authorization: Session (Organiser)

Response: 200 OK
[
  {
    "id": 1,
    "participantId": 2,
    "eventId": 1,
    "categoryId": 1,
    "enrolledAt": "2024-01-01T00:00:00Z"
  }
]

Response: 403 Forbidden
```

#### Get Enrolment by ID
```
GET /api/events/{eventId}/enrolments/{enrolmentId}
Authorization: Session

Response: 200 OK
{
  "id": 1,
  "participantId": 2,
  "eventId": 1,
  "categoryId": 1,
  "enrolledAt": "2024-01-01T00:00:00Z"
}

Response: 403 Forbidden or 404 Not Found
```

#### Enrol in Event (Participant Only)
```
POST /api/events/{eventId}/enrolments
Authorization: Session (Participant)
Content-Type: application/json

Request:
{
  "categoryId": 1
}

Response: 201 Created
{
  "id": 1,
  "participantId": 2,
  "eventId": 1,
  "categoryId": 1,
  "enrolledAt": "2024-01-01T00:00:00Z"
}

Response: 400 Bad Request (already enrolled)
Response: 403 Forbidden (if not participant)
Response: 404 Not Found (event or category)
```

#### Cancel Enrolment
```
DELETE /api/events/{eventId}/enrolments/{enrolmentId}
Authorization: Session

Response: 200 OK
{
  "message": "Enrolment cancelled successfully"
}

Response: 403 Forbidden (if not participant) or 404 Not Found
```

### Result Endpoints

#### List Results for Event (Organiser Only)
```
GET /api/events/{eventId}/results
Authorization: Session (Organiser)

Response: 200 OK
[
  {
    "id": 1,
    "participantId": 2,
    "eventId": 1,
    "finishTime": "02:30:45.1234567",
    "finishingPosition": 1,
    "recordedAt": "2024-01-01T00:00:00Z"
  }
]

Response: 403 Forbidden
```

#### Get Result by ID
```
GET /api/events/{eventId}/results/{resultId}
Authorization: Session

Response: 200 OK
{
  "id": 1,
  "participantId": 2,
  "eventId": 1,
  "finishTime": "02:30:45.1234567",
  "finishingPosition": 1,
  "recordedAt": "2024-01-01T00:00:00Z"
}

Response: 403 Forbidden or 404 Not Found
```

#### Get Participant Results
```
GET /api/events/{eventId}/results/participant/{participantId}
Authorization: Session

Response: 200 OK
[
  {
    "id": 1,
    "participantId": 2,
    "eventId": 1,
    "finishTime": "02:30:45.1234567",
    "finishingPosition": 1,
    "recordedAt": "2024-01-01T00:00:00Z"
  }
]

Response: 403 Forbidden
```

#### Record Result (Organiser Only)
```
POST /api/events/{eventId}/results
Authorization: Session (Organiser)
Content-Type: application/json

Request:
{
  "participantId": 2,
  "finishTime": "02:30:45.1234567",
  "finishingPosition": 1
}

Response: 201 Created
{
  "id": 1,
  "participantId": 2,
  "eventId": 1,
  "finishTime": "02:30:45.1234567",
  "finishingPosition": 1,
  "recordedAt": "2024-01-01T00:00:00Z"
}

Response: 400 Bad Request (not enrolled or result exists)
Response: 403 Forbidden or 404 Not Found
```

#### Update Result (Organiser Only)
```
PUT /api/events/{eventId}/results/{resultId}
Authorization: Session (Organiser)
Content-Type: application/json

Request:
{
  "participantId": 2,
  "finishTime": "02:30:45.1234567",
  "finishingPosition": 1
}

Response: 200 OK
{
  "id": 1,
  "participantId": 2,
  "eventId": 1,
  "finishTime": "02:30:45.1234567",
  "finishingPosition": 1,
  "recordedAt": "2024-01-01T00:00:00Z"
}
```

#### Delete Result (Organiser Only)
```
DELETE /api/events/{eventId}/results/{resultId}
Authorization: Session (Organiser)

Response: 200 OK
{
  "message": "Result deleted successfully"
}
```

## Error Responses

### 400 Bad Request
```json
{
  "message": "Description of the validation error"
}
```

### 401 Unauthorized
```json
{
  "message": "Not authenticated"
}
```

### 403 Forbidden
```json
{
  "message": "Access denied" or "Only organisers/participants can perform this action"
}
```

### 404 Not Found
```json
{
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "message": "An internal server error occurred"
}
```

## Testing the API

Use tools like:
- **Swagger UI**: Available at `/swagger/index.html`
- **Postman**: Import API collection for testing
- **curl**: Command-line API testing
- **Unit Tests**: xUnit test suite included

## Security Considerations

1. **Password Hashing**: All passwords are hashed with SHA256
2. **Session Management**: Sessions expire after 30 minutes of inactivity
3. **HTTPS**: Always use HTTPS in production
4. **CORS**: Configure CORS appropriately for your front-end domain
5. **Input Validation**: All inputs are validated on the server

## Rate Limiting

Currently no rate limiting is implemented. This should be added for production deployments.

## Versioning

Current API Version: 1.0.0

No versioning strategy is currently implemented.
