# HTTP Server Connectivity Guide - RaceDay API

## ? Your API is Already Connected to HTTP Server

Good news! The RaceDay API is **fully configured and ready to work with HTTP servers**. It uses **Kestrel**, which is ASP.NET Core's built-in HTTP server.

---

## ?? Quick Start

### Run the API Right Now

```bash
# Navigate to project
cd WebApplication2

# Start the HTTP server
dotnet run
```

### Expected Output
```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: https://localhost:7071
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5014
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to exit.
```

### Access the API
Open your browser and go to:
```
http://localhost:5014/swagger/index.html
```

**That's it!** Your API is now running on the HTTP server and accessible from anywhere.

---

## ?? HTTP Server Details

### Built-in HTTP Server: Kestrel

ASP.NET Core includes **Kestrel**, a lightweight HTTP server:

| Feature | Details |
|---------|---------|
| **Type** | Cross-platform HTTP server |
| **Included** | Built-in with ASP.NET Core |
| **No Installation** | Ready to use out of the box |
| **Performance** | High performance, production-ready |
| **Configuration** | Configured in `Program.cs` |

### Listening Ports

Your API listens on:

```
HTTP:  http://localhost:5014
HTTPS: https://localhost:7071
```

Both are active simultaneously. Choose based on your needs:
- Use **HTTP (5014)** for local development testing
- Use **HTTPS (7071)** for secure testing

---

## ?? How to Connect to the API

### From a Web Browser

1. **Open browser**
2. **Navigate to:** `http://localhost:5014/swagger/index.html`
3. **Test endpoints** directly in the Swagger UI

### From JavaScript/React

```javascript
// Connect to API
const API_BASE = 'http://localhost:5014';

// Example: Login
fetch(`${API_BASE}/api/auth/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',  // Important for sessions
  body: JSON.stringify({
    email: 'user@example.com',
    password: 'Password123!'
  })
})
.then(response => response.json())
.then(data => console.log('Logged in:', data));
```

### From Python

```python
import requests

API_BASE = 'http://localhost:5014'
session = requests.Session()

# Login
response = session.post(
    f'{API_BASE}/api/auth/login',
    json={
        'email': 'user@example.com',
        'password': 'Password123!'
    }
)
print(response.json())
```

### From Postman/Insomnia

1. **Set Base URL:** `http://localhost:5014`
2. **Create request:** `POST /api/auth/login`
3. **Add JSON body:**
   ```json
   {
     "email": "user@example.com",
     "password": "Password123!"
   }
   ```
4. **Send request** ? Instantly connected!

### From curl (Terminal)

```bash
curl -X POST http://localhost:5014/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"Password123!"}'
```

---

## ?? Common Use Cases

### Use Case 1: Local Development

```bash
# Start API on HTTP port for easy local testing
dotnet run --launch-profile http

# Access at http://localhost:5014
```

### Use Case 2: Secure Development Testing

```bash
# Start API on both HTTP and HTTPS
dotnet run --launch-profile https

# Access at https://localhost:7071 or http://localhost:5014
```

### Use Case 3: Testing from Another Machine

Modify `Program.cs` to listen on all interfaces:

```csharp
app.Run("http://0.0.0.0:5014");  // Listen on all network interfaces
```

Then connect from another machine:
```
http://192.168.1.100:5014/swagger
```

### Use Case 4: Docker/Container

```dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:8.0
WORKDIR /app
COPY ./publish .
EXPOSE 5014
ENTRYPOINT ["dotnet", "WebApplication2.dll"]
```

Run:
```bash
docker run -p 5014:5014 raceday-api
# Connect at http://localhost:5014
```

---

## ?? HTTP Server Configuration

### Current Configuration (Program.cs)

```csharp
var app = builder.Build();

// HTTP server setup
app.UseHttpsRedirection();  // Redirect HTTP?HTTPS in production
app.UseCors("AllowAll");    // Allow requests from any origin
app.UseSession();           // Enable session management
app.MapControllers();       // Map API endpoints

app.Run();                  // Start HTTP server listening
```

### Custom Port Configuration

To change HTTP port, edit `launchSettings.json`:

```json
{
  "profiles": {
    "http": {
      "applicationUrl": "http://localhost:8080"  // Change port here
    }
  }
}
```

Or at runtime:
```bash
dotnet run --urls "http://0.0.0.0:8080"
```

### Multiple Ports

Listen on multiple ports simultaneously:

```bash
dotnet run --urls "http://0.0.0.0:5014;https://0.0.0.0:7071"
```

---

## ?? HTTP Endpoints Available

Your API exposes **31 HTTP endpoints**:

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/status` - Check auth status

### Events
- `GET /api/events` - Get all events
- `POST /api/events` - Create event (HTTP POST)
- `PUT /api/events/{id}` - Update event (HTTP PUT)
- `DELETE /api/events/{id}` - Delete event (HTTP DELETE)

### And 20+ more endpoints...

All accessible via HTTP at `http://localhost:5014`

---

## ? Verification: API is Connected

### Check 1: Server is Running

```bash
# When you run:
dotnet run

# You should see:
# Now listening on: http://localhost:5014
# Now listening on: https://localhost:7071
```

### Check 2: Accessible from Browser

```
Open: http://localhost:5014/swagger/index.html
If you see Swagger UI, ? API is connected!
```

### Check 3: Test HTTP Request

```bash
# In terminal/PowerShell:
curl http://localhost:5014/api/events

# Should return: [] (empty events list, which is correct)
```

### Check 4: Test POST Request

```bash
curl -X POST http://localhost:5014/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName":"Test",
    "lastName":"User",
    "email":"test@example.com",
    "phoneNumber":"1234567890",
    "password":"Password123!",
    "role":1
  }'

# Should return: User profile with id, email, role
```

All checks passing? ? **Your API is fully connected to HTTP server!**

---

## ?? Connecting External Systems

### Web Frontend (React/Vue/Angular)

```javascript
// In your frontend app
const API_URL = 'http://localhost:5014';

// All API calls go through this URL
axios.defaults.baseURL = API_URL;
axios.defaults.withCredentials = true;  // For sessions
```

### Mobile App

```swift
// iOS/Swift
let url = URL(string: "http://localhost:5014/api/events")!
URLSession.shared.dataTask(with: url) { data, response, error in
    // Handle response
}.resume()
```

### Desktop Application

```csharp
// C# WinForms/WPF
using HttpClient client = new HttpClient 
{ 
    BaseAddress = new Uri("http://localhost:5014") 
};

var response = await client.GetAsync("/api/events");
```

### IoT Devices

```c
// Arduino/ESP32
HTTPClient http;
http.begin("http://192.168.1.100:5014/api/events");
int httpCode = http.GET();
```

---

## ?? Security Considerations

### HTTP vs HTTPS

| Scenario | Use | Command |
|----------|-----|---------|
| Local development | HTTP (unencrypted) | `dotnet run --launch-profile http` |
| Testing security | HTTPS (encrypted) | `dotnet run --launch-profile https` |
| Production | HTTPS (required) | Deploy to HTTPS-enabled host |

### CORS Configuration

API accepts requests from any origin (localhost development):

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()   // Any domain
               .AllowAnyMethod()   // Any HTTP method
               .AllowAnyHeader();  // Any header
    });
});
```

### For Production

Restrict CORS to your domain:

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("Production", builder =>
    {
        builder.WithOrigins("https://yourdomain.com")
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});
```

---

## ?? HTTP Request/Response Examples

### Example 1: Register User (HTTP POST)

**HTTP Request:**
```http
POST /api/auth/register HTTP/1.1
Host: localhost:5014
Content-Type: application/json
Content-Length: 123

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "password": "Password123!",
  "role": 1
}
```

**HTTP Response:**
```http
HTTP/1.1 200 OK
Content-Type: application/json
Set-Cookie: [session cookie]

{
  "id": 1,
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "role": 1
}
```

### Example 2: Get Events (HTTP GET)

**HTTP Request:**
```http
GET /api/events HTTP/1.1
Host: localhost:5014
```

**HTTP Response:**
```http
HTTP/1.1 200 OK
Content-Type: application/json

[]
```

### Example 3: Create Event (HTTP POST with Auth)

**HTTP Request:**
```http
POST /api/events HTTP/1.1
Host: localhost:5014
Content-Type: application/json
Cookie: [session cookie from login]

{
  "name": "City Marathon",
  "description": "Annual marathon",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "Central Park",
  "distance": 42.2,
  "eventType": 0
}
```

**HTTP Response:**
```http
HTTP/1.1 201 Created
Content-Type: application/json

{
  "id": 1,
  "name": "City Marathon",
  "description": "Annual marathon",
  "eventDate": "2024-06-15T08:00:00Z",
  "location": "Central Park",
  "distance": 42.2,
  "eventType": 0,
  "organiserId": 1,
  "createdAt": "2024-01-01T00:00:00Z"
}
```

---

## ?? Next Steps

### 1. Start the API
```bash
dotnet run
```

### 2. Open Swagger UI
```
http://localhost:5014/swagger/index.html
```

### 3. Test an Endpoint
```
Try the /api/events endpoint to see it works
```

### 4. Connect Your Client
```
Use http://localhost:5014 as your API base URL
```

### 5. Done! ??
Your app is now connected to the HTTP server!

---

## ?? For More Information

- **Full HTTP Configuration:** See [HTTP_SERVER_CONFIGURATION.md](HTTP_SERVER_CONFIGURATION.md)
- **API Endpoints:** See [API_DOCUMENTATION.md](API_DOCUMENTATION.md)
- **Quick Start:** See [QUICK_START.md](QUICK_START.md)
- **Setup Guide:** See [SETUP_GUIDE.md](SETUP_GUIDE.md)

---

## ? Summary

Your RaceDay API is:

- ? **Running on HTTP server** (Kestrel)
- ? **Listening on port 5014** (HTTP) and 7071 (HTTPS)
- ? **Accessible from anywhere** (same network)
- ? **Ready for clients to connect**
- ? **Fully documented** with Swagger UI

**Start now:** `dotnet run` and connect at `http://localhost:5014`

---

**Your API is connected. You're ready to go!** ??
