#!/bin/bash
# RaceDay API - Universal Startup Script (for PowerShell and Bash)

echo "=========================================="
echo "   RaceDay API - Universal Startup"
echo "=========================================="
echo ""

# Check .NET version
echo "[1/5] Checking .NET installation..."
dotnet --version
if [ $? -ne 0 ]; then
    echo "ERROR: .NET is not installed"
    exit 1
fi
echo "? .NET is installed"
echo ""

# Navigate to project
echo "[2/5] Navigating to project..."
cd "C:\Users\Student\source\repos\WebApplication2\WebApplication2" 2>/dev/null || cd "/c/Users/Student/source/repos/WebApplication2/WebApplication2" 2>/dev/null || cd "WebApplication2" 2>/dev/null
echo "? Project directory ready"
echo ""

# Restore packages
echo "[3/5] Restoring NuGet packages..."
dotnet restore
if [ $? -ne 0 ]; then
    echo "ERROR: Package restore failed"
    exit 1
fi
echo "? Packages restored"
echo ""

# Create/Update database
echo "[4/5] Setting up database..."
dotnet ef database update
if [ $? -ne 0 ]; then
    echo "WARNING: Database setup had issues"
fi
echo "? Database ready"
echo ""

# Run the API
echo "[5/5] Starting API server..."
echo ""
echo "=========================================="
echo "   API Server Starting..."
echo "=========================================="
echo ""
echo "The API will be available at:"
echo "  HTTP:  http://localhost:5014"
echo "  HTTPS: https://localhost:7071"
echo ""
echo "Swagger UI: http://localhost:5014/swagger/index.html"
echo ""
echo "Press Ctrl+C to stop"
echo ""
echo "=========================================="
echo ""

dotnet run
